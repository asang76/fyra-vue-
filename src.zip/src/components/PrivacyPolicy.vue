<template>
<div class=" bg-contain bg-center bg-gradient-to-b from-purple-600 to-purple-500 ">
     <div class=" rounded-full text-center text-white absolute font-extrabold opacity-30" style=" width:400px; height:40px;  font-size:100px; top:10px;  backdrop-filter:blur(2px)">let Us help you!
     </div>
<br />
<br />
<br />

<div class="
      grid
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-1
      lg: w-10/12
      border-1
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      bg-blue-800 bg-opacity-30 rounded-lg from-right m-4" style="backdrop-filter:blur(2px);
    ">
    <div class=" ">
        <div class="md:p-2  align-middle">
            <h1 class="mt-2 mb-4 font-bold leading-tight text-center text-yellow-400 bg-gray-400 bg-opacity-30 rounded-lg from-right m-4" style="backdrop-filter:blur(10px); font-size: 40px">
                Privacy Policy
            </h1>

            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-400" style="font-size: 20px"> WHAT INFORMATION DO WE COLLECT? </h2>

                We only collect information that we need that is related to your order. This includes your:
                <ul class="p-10 list-disc">
                    <li> Billing Address </li>
                    <li> Shipping Address </li>
                    <li> Email Address </li>
                    <li> Credit Card Information </li>
                </ul>

                In addition we also collect information on your IP address, browser type, and Refer URL data.

            </div>
            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-300" style="font-size: 20px"> WHAT DO WE DO WITH YOUR INFORMATION? </h2>

                When you purchase something from our store, as part of the buying and selling process, we collect the personal information you give us such as your name, address and email address.

<br>
<br>
                When you browse our store, we also automatically receive your computer’s internet protocol (IP) address, browser type, and Refer URL data. We use this data to prevent hacking attempts, help us know what web browsers people are using, and find out where our visitors are coming from so that we can improve our marketing.
<br>
<br>
                Email marketing (if applicable): With your permission, we may send you emails about our store, new products and other updates.

            </div>
            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-300" style="font-size: 20px"> CONSENT </h2>

                 <h3 class="mt-2 mb-4 font-bold leading-tight text-left" style="font-size: 16px"> How do you get my consent? </h3>

                When you provide us with personal information to complete a transaction, verify your credit card, place an order, arrange for a delivery or return a purchase, we imply that you consent to our collecting it and using it for that specific reason only.

<br>
<br>

                If we ask for your personal information for a secondary reason, like marketing, we will either ask you directly for your expressed consent, or provide you with an opportunity to say no.
<br>
<br>

                <h3 class="mt-2 mb-4 font-bold leading-tight text-left" style="font-size: 16px"> How do I withdraw my consent? </h3>

                If after you opt-in, you change your mind, you may withdraw your consent for us to contact you, for the continued collection, use or disclosure of your information, at anytime, by contacting us at customercare@fyra.biz or mailing us at:
              <br>
              <br>

               <table>
                   <tr>
                       <th class="text-pink-400">
                FYRA INSIGHTS PVT. LTD. </th>
                </tr>
                <tr>
               <td>  405, c/o, Sector 7, Town Square,</td>
               </tr>
               <tr>
                <td> Above Dorabjee,</td>
                </tr>
               <tr>
               <td>  Viman nagar, Pune </td>
               </tr>
               <tr>
               <td>  Maharashtra 411014 </td>
               </tr>
               </table>

            </div>
            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-400" style="font-size: 20px"> THIRD-PARTY SERVICES </h2>

                In general, the third-party providers used by us will only collect, use and disclose your information to the extent necessary to allow them to perform the services they provide to us.
                <br>
                <br>

                However, certain third-party service providers, such as payment gateways, analytics companies and other payment transaction processors, have their own privacy policies in respect to the information we are required to provide to them for your browsing or purchasing behavior.
                 <br>
                <br>

                For these providers, we recommend that you read their privacy policies so you can understand the manner in which your personal information will be handled by these providers.

 <br>
                <br>
                In particular, remember that certain providers may be located in or have facilities that are located a different jurisdiction than either you or us. So if you elect to proceed with a transaction that involves the services of a third-party service provider, then your information may become subject to the laws of the jurisdiction(s) in which that service provider or its facilities are located.

 <br>
                <br>
                As an example, if you are located in United States and your transaction is processed by a payment gateway located in the India, then your personal information used in completing that transaction may be subject to disclosure under India legislation.

 <br>
                <br>

                Once you leave our website or are redirected to a third-party website or application, you are no longer governed by this Privacy Policy or our website’s Terms of Service.

            </div>
            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-400" style="font-size: 20px"> LINKS</h2>

                When you click on links on our web site, they may direct you away from our site. We are not responsible for the privacy practices of other sites and encourage you to read their privacy statements.

            </div>
            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-400" style="font-size: 20px"> SECURITY</h2>

                To protect your personal information, we take reasonable precautions and follow industry best practices to make sure it is not inappropriately lost, misused, accessed, disclosed, altered or destroyed.

                If you provide us with your credit card information, the information is encrypted using secure socket layer technology (SSL) and stored with a AES-256 encryption. Although no method of transmission over the Internet or electronic storage is 100% secure, we follow all PCI-DSS requirements and implement additional generally accepted industry standards.

            </div>
            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-400" style="font-size: 20px"> COOKIES </h2>
                On the site, cookies do several different jobs. They let you navigate between pages efficiently, remember your preferences, and generally improve your experience on the Site. They can also help to ensure that advertisements that you see online are more relevant to you and your interests.

                You can adjust the settings in your browser in order to restrict or block cookies that are set by the Site (or any other site on the Internet). Your browser may include information on how to adjust your settings. Alternatively, you may visit www.allaboutcookies.org to obtain comprehensive general information about cookies and how to adjust the cookie settings on various browsers. Please be aware that restricting cookies may impact the functionality of the Site.

            </div>

            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-400" style="font-size: 20px"> AGE OF CONSENT </h2>
                By using this site, you represent that you are at least the age of majority in your state or province of residence, or that you are the age of majority in your state or province of residence and you have given us your consent to allow any of your minor dependents to use this site.

            </div>

            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-400" style="font-size: 20px"> CHANGES TO THIS PRIVACY POLICY </h2>
                We reserve the right to modify this privacy policy at any time, so please review it frequently. Changes and clarifications will take effect immediately upon their posting on the website. If we make material changes to this policy, we will notify you here that it has been updated, so that you are aware of what information we collect, how we use it, and under what circumstances, if any, we use and/or disclose it.

                If our store is acquired or merged with another company, your information may be transferred to the new owners so that we may continue to sell products to you.

            </div>

            <div class="
            text-justify text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px">

                <h2 class="mt-2 mb-4 font-bold leading-tight text-left text-yellow-400" style="font-size: 20px"> QUESTIONS AND CONTACT INFORMATION </h2>
                If you would like to: access, correct, amend or delete any personal information we have about you, register a complaint, or simply want more information contact at customercare@fyra.biz or by mail at:

<br>
<br>
<table>
                   <tr>
                       <th class="text-pink-400">
                FYRA INSIGHTS PVT. LTD. </th>
                </tr>
                <tr>
               <td>  405, c/o, Sector 7, Town Square,</td>
               </tr>
               <tr>
                <td> Above Dorabjee,</td>
                </tr>
               <tr>
               <td>  Viman nagar, Pune </td>
               </tr>
               <tr>
               <td>  Maharashtra 411014 </td>
               </tr>
               </table>
               <br>
               <br>
                Customers have questions, you have answers. Display the most frequently asked questions, so everybody benefits.

            </div>

        </div>
    </div>

</div>

<br />
<br />
<br />
</div>
</template>
