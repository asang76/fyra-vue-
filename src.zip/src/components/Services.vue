<template>
<!-- space creator -->
<br>
<br>
<br>
<div class=" bg-contain bg-center bg-gradient-to-b from-purple-800 to-purple-300">
  <!-- <div class=" rounded-full text-white absolute font-extrabold  text-right opacity-30" style=" width:80px; height:40px;  font-size:100px; top:px; right:1px  backdrop-filter:blur(2px)">Shop Platform!
     </div> -->
<br>
<br>
<br>
<div>
    <div class="w-96 top-20 h-4/5 absolute right-1 "> <svg id="visual" viewBox="0 0 960 540" width="" height="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"><g transform="translate(394.6700127415268 205.73521185929957)"><path d="M142.9 -165.4C206.5 -150.5 293.9 -137.2 338.3 -89.1C382.6 -40.9 383.9 42.1 354.8 110.2C325.8 178.4 266.3 231.6 202.1 270.7C137.9 309.8 69 334.9 2.3 331.8C-64.5 328.7 -128.9 297.4 -163.2 248.6C-197.4 199.7 -201.4 133.2 -203.1 77.8C-204.8 22.5 -204.2 -21.8 -193.5 -65.5C-182.9 -109.1 -162.3 -152 -128.4 -176.5C-94.4 -201 -47.2 -207 -3.8 -201.8C39.7 -196.6 79.4 -180.2 142.9 -165.4" fill="#aba08c"></path></g></svg></div>
    <div class="grid grid-cols-2">
          <div class="relative w-full left-20 top-20 h-96">
    <!-- <div class="bg-green-600 w-96 h-96 rotate right-10  rounded-full -z-10 absolute opacity-25"></div>
    <div class="bg-yellow-600 w-72 h-72 rotate right-10 rounded-full -z-10 absolute opacity-25"></div> -->
        <div class="md:p-2 align-middle">
            <!--  <h1 class="text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-green-300 h-auto"> -->
            <h1 class="-mt-40 sm:text-3xl md:text-4xl head text-2xl text-yellow-400 font-bold m-2">
  <span>You  </span>
  <span>are </span>
  <span>at </span>
  <span>Right </span>
  <span>Place </span>
  <span>Fyra </span>
  <span>can </span>
  <span>be </span>
  <span>your, </span>
  <span>right </span>
  <span>Digital </span>
  <span>Partner! </span>
   <span class="text-sm ">Fyra insights is a one-stop solution for
                all your needs when it comes to getting your business online and Selling Online is only a part of it. Online presence is much more than that. Fyra offers you the complete package as PasserBy Platform. PasserBy platform includes a personalized app for your branding, a delivery app with all tracking features and a business app for sales management and business insights. Our platform helps you to build an online presence of your business which will ultimately lead to an increase in your sales. In case you need any digital marketing service our team is there to support you. We offer warehousing and shipping support also for our clients. We have tie-ups in the right places to serve your specific needs. We have tailored packages to meet the specific requirements. </span> 
  <!--span>place </-span>
  <span>on</span>
  <span>your</span>
  <span>own</span>
  <span>thinking.</span> -->
</h1>

        </div>
          <div class="
            text-center
            px-16
            leading-normal
            transform
            transition
            duration-500
            hover:scale-110
          " style="font-size: 16px">
                 <a href="https://dashboard.passerby.in/register/">
                     <button class="
              mx-auto
              lg:mx-0
              hover:underline
              bg-indigo-600
              text-white
              font-bold
              rounded-full
              my-6
              py-4
              px-8
              shadow-lg
              focus:outline-none
              focus:shadow-outline
              transform
              transition
              hover:scale-105
              duration-300
              ease-in-out
              w-25
              text-center
            ">
                         Register
                     </button>
                 </a> &nbsp; &nbsp;
                 <a >

                     <button class="
              mx-auto
              lg:mx-0
              hover:underline
              bg-indigo-600
              text-white
              font-bold
              rounded-full
              my-6
              py-4
              px-8
              shadow-lg
              focus:outline-none
              focus:shadow-outline
              transform
              transition
              hover:scale-105
              duration-300
              ease-in-out
              w-25
              text-center
            ">
                         Send Enquiry
                     </button>
                 </a>
             </div>
    </div>
    </div>
</div>
    <div class="wave ">
    <div class="custom-shape-divider-bottom-1643726750">
    <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
        <path d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z" class="shape-fill"></path>
    </svg>
</div>
 </div>


<div class="
      grid 
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-56
    ">
    <div class="col-span-3 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">

            <h1 class="text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-br from-blue-400 to-purple-600 " style="font-size: 20px">
                You are at Right Place
            </h1>
            <h1 class="mb-10 text-7xl font-extrabold text-transparent bg-clip-text bg-gradient-to-br from-blue-400 to-purple-600" style="font-size: 40px">
                Fyra can be your right Digital Partner!
            </h1>

            <!--div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div-->
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                <!-- Fyra insights is a one-stop solution for
                all your needs when it comes to getting your business online and Selling Online is only a part of it. Online presence is much more than that. Fyra offers you the complete package as PasserBy Platform. PasserBy platform includes a personalized app for your branding, a delivery app with all tracking features and a business app for sales management and business insights. Our platform helps you to build an online presence of your business which will ultimately lead to an increase in your sales. In case you need any digital marketing service our team is there to support you. We offer warehousing and shipping support also for our clients. We have tie-ups in the right places to serve your specific needs. We have tailored packages to meet the specific requirements. -->

            </div>

        </div>
    </div>
</div>
<div class=" w-10/12  flex justify-center mt-20">

            <div class="container gap-4 ml-20 grid grid-cols-2 ">
                <div class="col-span-3 md:col-span-1 sm:col-span-3 md:ml-20 md:-mt-2">
                    <div class="ml-20 w-32 " ><h1 class="text-3xl relative border-b-8"> <span class="text-white font-bold ">BRANDING</span> </h1></div>
                <div class="w-10/12 h-96 hover:text-2xl rounded-2xl bg-white relative" style="background-image:url('https://fyra.biz/static/img/fyra-branding.jpg')">  <div  class="layer"><h3 class="text-sm p-2 absolute bottom-1 left-20"><hr> <p class="whitespace-normal indent-8 p-4">Branding is an intimate and intensive exercise Your brand needs to communicate consistently across all the channels to give a uniform experience to your stakeholders It requires a lot of inputs and time from the business owners, but once done correctly, it can be useful for the next 5 to 10 years We help you right from creating your logo, your website and help you in Digital Marketing delivering a consistent communication across channels</p> </h3></div>
                </div>
                </div>
                
                   <div class="col-span-3 md:col-span-1 sm:col-span-3 md:-mt-4">
                    <div class="ml-20 w-32" ><h1 class="text-3xl relative  border-b-8"> <span class="text-white font-bold ">E-Commerce</span> </h1></div>
                <div class="w-10/12 h-96 hover:text-2xl rounded-2xl bg-white relative"> <div  class="layer"><h3 class="text-sm md:absolute bottom-1 md:left-20"><hr> <ul class="text-lg  p-4 text-left">
                    <li>E-commerce is here to stay</li>
                    <li> The faster we realize that the faster we can move to be a part of it</li>
                    <li> Through our PasserBy Platform, we help companies set up their online store on their own website</li>
                    <li> We also help them onboard on the Leading marketplaces such as Amazon and Flipkart</li>
                    </ul> </h3></div>
                </div>
                </div>
                   <div class="col-span-3 md:col-span-1 sm:col-span-3 md:-mt-4">
                    <div class="ml-20 w-32" ><h1 class="text-3xl relative  border-b-8"> <span class="text-white font-bold ">Warehousing</span> </h1></div>
                <div class="w-10/12 h-96 hover:text-2xl rounded-2xl bg-white relative"> <div  class="layer"><h3 class="text-sm md:absolute bottom-1 md:left-20"><hr> <ul class="text-lg  p-4 text-left">
                    <li>Some SMEs don’t have any experience in storing products in small packing</li>
                    <li>Additionally, sometimes the items need to be distributed throughout the country for faster shipping</li>
                    <li> We help you in getting the right warehouse across the country so that you can reach your customers faster</li>
                    </ul> </h3></div>
                </div>
                </div>
               
                   <div class="col-span-3 md:col-span-1  sm:col-span-3  md:mt-10">
                    <div class="md:ml-20 w-32 " ><h1 class="text-3xl relative  border-b-8"> <span class="text-white font-bold "> Shipping</span> </h1></div>
                <div class="w-10/12 h-96 hover:text-2xl rounded-2xl bg-white relative"> <div  class="layer"><h3 class="text-sm absolute bottom-1 md:left-20"><hr> <ul class="text-lg h-40 p-4 mb-10 text-left">
                    <li>Shipping in Online business is a huge challenge</li>
                    <li>The cost of logistics is inverted in the online model</li>
                    <li> This is one area where margins are eaten up</li>
                    <li>We help you get the right shipping partner across the world</li>
                    </ul></h3></div>
                </div>
                </div>
                </div>
               
               
                
            </div>

<!-- <div class="
      grid 
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
    ">
    <div class="bg-white p-2">
        <img src="/static/img/fyra-branding.jpg" alt="Branding" class="sm:h-48 md:h-64 lg:h-128" />
    </div>

    <div class="col-span-2 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center" style="font-size: 28px">
                Branding
            </h1>

            <div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                Branding is an intimate and intensive exercise
                Your brand needs to communicate consistently across all the channels to give a uniform experience to your stakeholders
                It requires a lot of inputs and time from the business owners, but once done correctly, it can be useful for the next 5 to 10 years
                We help you right from creating your logo, your website and help you in Digital Marketing delivering a consistent communication across channels

            </div>

        </div>
    </div>
</div>

<div class="
      grid 
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
    ">

    <div class="col-span-2 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center" style="font-size: 28px">
                E-Commerce
            </h1>

            <div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                E-commerce is here to stay

                The faster we realize that the faster we can move to be a part of it

                Through our PasserBy Platform, we help companies set up their online store on their own website

                We also help them onboard on the Leading marketplaces such as Amazon and Flipkart

            </div>

        </div>
    </div>
    <div class="bg-white p-2">
        <img src="/static/img/fyra-ecommerce.jpg" alt="E-Commerce" class="sm:h-48 md:h-64 lg:h-128" />
    </div>
</div>

<div class="
      grid 
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
    ">
    <div class="bg-white p-2">
        <img src="/static/img/fyra-warehouse.jpg" alt="Branding" class="sm:h-48 md:h-64 lg:h-128" />
    </div>

    <div class="col-span-2 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center" style="font-size: 28px">
                Warehousing
            </h1>

          div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                Some SMEs don’t have any experience in storing products in small packing
                Additionally, sometimes the items need to be distributed throughout the country for faster shipping
                We help you in getting the right warehouse across the country so that you can reach your customers faster

            </div>

        </div>
    </div>
</div>

<div class="
      grid 
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
    ">

    <div class="col-span-2 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center" style="font-size: 28px">
                Shipping
            </h1>

            <div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                Shipping in Online business is a huge challenge

                The cost of logistics is inverted in the online model

                This is one area where margins are eaten up

                We help you get the right shipping partner across the world

            </div>

        </div>
    </div>
    <div class="bg-white p-2">
        <img src="/static/img/fyra-shipping.jpg" alt="E-Commerce" class="sm:h-48 md:h-64 lg:h-128" />
    </div> -->
</div>
</template>

<script>
import {
    mapGetters
} from "vuex";

export default {
    name: "Services",
    data() {
        return {
            activeTab: 'product',
        }
    },

    methods: {
        set_link() {
            this.$store.dispatch("ACTIVE_LINK", {
                active_link: "products",
            });
        },
        toggle_tabs(tabname) {
            this.activeTab = tabname;

        },

    },
    computed: {
        ...mapGetters({
            active_link: "active_link",
        }),
    },

    created() {
        this.set_link();
    },
};
</script>

<style scoped>
.active {
    background-color: transparent;
    border-radius: 10px;
    border-bottom: 5px solid blue;
    ;
}
.layer{
    background: transparent;
    height: 100%;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    transition: 0.5s;
    overflow: hidden;
    border-radius: 15px;
}

.layer:hover{
    background: rgba(226,0,0,0.7);
    
}

.layer h3{
    width: 100%;
    font-weight: 500;
    color: #fff;
    font-size: 26px;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    position: absolute;
    opacity: 0;
    transition: 0.5s;
}

.layer:hover h3{
    bottom: 10%;
    opacity: 1;
}
.wave {
    position: absolute;
    bottom: -35px;
    left: 0;
    width: 100%;
    overflow: hidden;
    line-height: 0;
}

.wave svg {
    position: relative;
    display: block;
    width: calc(100% + 1.3px);
    height: 143px;
    transform: rotateY(180deg);
}

.wave .shape-fill {
    fill: #5a32a5;
}
.wave{
    animation-name: ani;
    animation-duration: 3000ms;
    animation-direction: normal;
    animation-fill-mode: initial;
}
.head span {
  display: inline-block;
  opacity: 0;
  filter: blur(4px);
  padding: 4px;
}

.head span:nth-child(1) {
  animation: fade-in 0.8s 0.1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(2) {
  animation: fade-in 0.8s 0.2s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(3) {
  animation: fade-in 0.8s 0.3s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(4) {
  animation: fade-in 0.8s 0.4s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

 .head span:nth-child(5) {
  animation: fade-in 0.8s 0.5s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(6) {
  animation: fade-in 0.8s 0.6s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(7) {
  animation: fade-in 0.8s 0.7s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

span:nth-child(8) {
  animation: fade-in 0.8s 0.8s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(9) {
  animation: fade-in 0.8s 0.9s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(10) {
  animation: fade-in 0.8s 1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(11) {
  animation: fade-in 0.8s 1.1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(12) {
  animation: fade-in 0.8s 1.2s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(13) {
  animation: fade-in 0.8s 1.3s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(14) {
  animation: fade-in 0.8s 1.4s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(15) {
  animation: fade-in 0.8s 1.5s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

 .head span:nth-child(16) {
  animation: fade-in 0.8s 1.6s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

/* .head span:nth-child(17) {
  animation: fade-in 0.8s 1.7s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(18) {
  animation: fade-in 0.8s 1.8s forwards cubic-bezier(0.11, 0, 0.5, 0);
} */

@keyframes fade-in {
  100% {
    opacity: 1;
    filter: blur(0);
  }
}
</style>
