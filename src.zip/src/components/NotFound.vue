<template>


<div class="m-40"> 

  <h1>Oops, it looks like the page you're looking for doesn't exist.</h1>
  </div> 

</template>
<style scoped>

h1 {
  font-size: 24px;

  background: #121FCF;
background: -webkit-linear-gradient(to right, #121FCF 3%, #CF1512 100%);
background: -moz-linear-gradient(to right, #121FCF 3%, #CF1512 100%);
background: linear-gradient(to right, #121FCF 3%, #CF1512 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
}

</style>