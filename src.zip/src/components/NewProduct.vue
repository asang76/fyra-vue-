<template>

<!-- space creator --> 
<div class="grid grid-cols-1 divide-y ">
    <div> </div>
    <div>
        <br> 
    </div>
</div>


<div class="container mx-auto">
    <div class="flex flex-col  sm:flex-row justify-between mx-4 md:mx-0 lg:-mx-2 flex-wrap">

        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <div class="p-4 md:p-6 text-black flex flex-col flex-1 ">
            
                <div class="text-xl text-left pt-10">
                    Fyra insights is a one-stop solution for all your needs when it comes to getting your business online and Selling Online is only a part of it. Online presence is much more than that. Fyra offers you the complete package as PasserBy Platform. PasserBy platform includes a personalized app for your branding, a delivery app with all tracking features and a business app for sales management and business insights. Our platform helps you to build an online presence of your business which will ultimately lead to an increase in your sales. In case you need any digital marketing service our team is there to support you. We offer warehousing and shipping support also for our clients. We have tie-ups in the right places to serve your specific needs. We have tailored packages to meet the specific requirements.

                </div>
                <br>
                <br>
                <br>

            </div>

        </div>

    </div>
</div>


<div class="grid grid-cols-1 divide-y divide-gray-100">
    <div> </div>
    <div>
    </div>
</div>

<br>

<div class="container mx-auto">
    <div class="flex flex-col  sm:flex-row justify-between mx-4 md:mx-0 lg:-mx-2 flex-wrap">

        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <div class="p-4 md:p-6 bg-black text-white flex flex-col flex-1 ">
                <p class="text-white-500 font-semibold text-5xl mb-1 leading-none">Business Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby Business Application</h3>
                </a>
                <div class="text-sm flex items-center">
                    <svg class="opacity-75 mr-2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="12" height="12" viewBox="0 0 97.16 97.16" style="enable-background: new 0 0 97.16 97.16;" xml:space="preserve">
                        <path d="M48.58,0C21.793,0,0,21.793,0,48.58s21.793,48.58,48.58,48.58s48.58-21.793,48.58-48.58S75.367,0,48.58,0z M48.58,86.823    c-21.087,0-38.244-17.155-38.244-38.243S27.493,10.337,48.58,10.337S86.824,27.492,86.824,48.58S69.667,86.823,48.58,86.823z"></path>
                        <path d="M73.898,47.08H52.066V20.83c0-2.209-1.791-4-4-4c-2.209,0-4,1.791-4,4v30.25c0,2.209,1.791,4,4,4h25.832    c2.209,0,4-1.791,4-4S76.107,47.08,73.898,47.08z"></path>
                    </svg>
                    <p class="leading-none">Hari Sadu </p>
                </div>
                <br>
                <br>
                <br>

            </div>

            <img src="/static/img/standingdesk.jpg" alt="People" class="w-full object-cover h-32 sm:h-48 md:h-64" />

        </div>

    </div>
</div>

<div class="grid grid-cols-1 divide-y divide-gray-100">
    <div> </div>
    <div>
    </div>
</div>

<div class="pt-10">
    <h1 class="text-4xl font-normal leading-normal mt-0 mb-2 text-black-800 text-center">
        Elite Club Members!
    </h1>

</div>

<div class="container mx-auto">
    <div class="flex flex-col sm:flex-row justify-between mx-4 md:mx-0 lg:-mx-2 flex-wrap">

        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <img src="/static/img/dropper-08.jpg" alt="People" class="w-full object-contain h-32 sm:h-48 md:h-64" />
            <div class="p-4 md:p-6 bg-white flex flex-col flex-1">
                <p class="text-blue-500 font-semibold text-xs mb-1 leading-none">Business Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby Business Application</h3>
                </a>
                <div class="text-sm flex items-center">
                    <svg class="opacity-75 mr-2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="12" height="12" viewBox="0 0 97.16 97.16" style="enable-background: new 0 0 97.16 97.16;" xml:space="preserve">
                        <path d="M48.58,0C21.793,0,0,21.793,0,48.58s21.793,48.58,48.58,48.58s48.58-21.793,48.58-48.58S75.367,0,48.58,0z M48.58,86.823    c-21.087,0-38.244-17.155-38.244-38.243S27.493,10.337,48.58,10.337S86.824,27.492,86.824,48.58S69.667,86.823,48.58,86.823z"></path>
                        <path d="M73.898,47.08H52.066V20.83c0-2.209-1.791-4-4-4c-2.209,0-4,1.791-4,4v30.25c0,2.209,1.791,4,4,4h25.832    c2.209,0,4-1.791,4-4S76.107,47.08,73.898,47.08z"></path>
                    </svg>
                    <p class="leading-none">Sopan Shewale</p>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="grid grid-cols-1 divide-y divide-gray-100">
    <div> </div>
    <div>
    </div>
</div>

<div class="pt-10">
    <h1 class="text-4xl font-normal leading-normal mt-0 mb-2 text-black-800 text-center">
        Support Services!
    </h1>

</div>

<div class="container mx-auto">
    <div class="flex flex-col sm:flex-row justify-between mx-4 md:mx-0 lg:-mx-2 flex-wrap">
        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <img src="https://source.unsplash.com/random" alt="product" class="w-full object-cover h-32 sm:h-48 md:h-64" />
            <div class="p-4 md:p-6 bg-white flex flex-col flex-1">
                <p class="text-blue-500 font-semibold text-xs mb-1 leading-none">User Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby</h3>
                </a>
                <div class="text-sm flex items-center">

                    <svg version="1.1" width="20px" height="20px" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 422.186 422.186" style="enable-background:new 0 0 422.186 422.186;" xml:space="preserve">
                        <g>
                            <g id="XMLID_14_">
                                <g>
                                    <path style="fill:#A7B6C4;" d="M134.729,242.243c-1.47,0-2.85-0.58-3.89-1.62c-1.04-1.03-1.61-2.42-1.61-3.88
                                c0-1.47,0.57-2.86,1.61-3.89l142.05-142.06c9.82-9.81,23.05-15.42,36.38-15.42c0.14,0,0.29,0,0.44,0.01
                                c13.3,0.12,25.8,5.37,35.21,14.78s14.66,21.91,14.78,35.2c0.13,13.48-5.49,26.9-15.41,36.82l-218.71,218.71
                                c-12.88,12.87-30.02,19.97-48.29,19.97c-19.22,0-37.65-8.16-50.58-22.38c-10.67-11.74-16.94-26.93-17.63-42.76
                                c-0.86-19.44,6.22-37.69,19.93-51.4l237.89-237.9c16.19-16.19,37.72-25.1,60.61-25.1c22.9,0,44.42,8.91,60.61,25.1
                                c33.42,33.43,33.42,87.81,0,121.23l-161.24,161.24c-1.04,1.04-2.42,1.61-3.89,1.61s-2.85-0.57-3.89-1.61
                                c-1.04-1.04-1.61-2.42-1.61-3.89s0.57-2.85,1.61-3.89l161.24-161.24c14.12-14.11,21.89-32.88,21.89-52.83
                                c0-19.96-7.77-38.73-21.89-52.84c-14.11-14.11-32.87-21.88-52.83-21.88c-0.04,0-0.08,0-0.12,0
                                c-19.62,0.03-39.07,8.24-53.36,22.53l-237.24,237.24c-10.82,10.82-16.78,25.21-16.78,40.51s5.96,29.69,16.78,40.51
                                c11.16,11.17,25.83,16.75,40.5,16.75s29.35-5.58,40.51-16.75l219.34-219.34c8.65-8.65,12.76-20.64,11.26-32.89
                                c-0.85-7-3.6-13.64-7.95-19.2c-7.6-9.73-18.99-15.31-31.23-15.31c-10.54,0-20.46,4.11-27.92,11.57l-142.68,142.68
                                C137.579,241.663,136.199,242.243,134.729,242.243z" />
                                    <path d="M130.839,240.623c1.04,1.04,2.42,1.62,3.89,1.62s2.85-0.58,3.89-1.62l142.68-142.68c7.46-7.46,17.38-11.57,27.92-11.57
                                c12.24,0,23.63,5.58,31.23,15.31c4.35,5.56,7.1,12.2,7.95,19.2c1.5,12.25-2.61,24.24-11.26,32.89l-219.34,219.34
                                c-11.16,11.17-25.84,16.75-40.51,16.75s-29.34-5.58-40.5-16.75c-10.82-10.82-16.78-25.21-16.78-40.51s5.96-29.69,16.78-40.51
                                l237.24-237.24c14.29-14.29,33.74-22.5,53.36-22.53c0.04,0,0.08,0,0.12,0c19.96,0,38.72,7.77,52.83,21.88
                                c14.12,14.11,21.89,32.88,21.89,52.84c0,19.95-7.77,38.72-21.89,52.83l-161.24,161.24c-1.04,1.04-1.61,2.42-1.61,3.89
                                s0.57,2.85,1.61,3.89c1.04,1.04,2.42,1.61,3.89,1.61s2.85-0.57,3.89-1.61l161.24-161.24c33.42-33.42,33.42-87.8,0-121.23
                                c-16.19-16.19-37.71-25.1-60.61-25.1c-22.89,0-44.42,8.91-60.61,25.1l-237.89,237.9c-13.71,13.71-20.79,31.96-19.93,51.4
                                c0.69,15.83,6.96,31.02,17.63,42.76c12.93,14.22,31.36,22.38,50.58,22.38c18.27,0,35.41-7.1,48.29-19.97l218.71-218.71
                                c9.92-9.92,15.54-23.34,15.41-36.82c-0.12-13.29-5.37-25.79-14.78-35.2s-21.91-14.66-35.21-14.78c-0.15-0.01-0.3-0.01-0.44-0.01
                                c-13.33,0-26.56,5.61-36.38,15.42l-142.05,142.06c-1.04,1.03-1.61,2.42-1.61,3.89
                                C129.229,238.203,129.799,239.593,130.839,240.623z M394.489,40.063c36.93,36.93,36.93,97.02,0,133.95l-161.25,161.24
                                c-2.73,2.74-6.38,4.25-10.25,4.25c-3.87,0-7.51-1.51-10.25-4.25c-2.74-2.73-4.25-6.38-4.25-10.25s1.51-7.51,4.25-10.25
                                l161.24-161.24c12.41-12.42,19.25-28.92,19.25-46.47c0-17.56-6.84-34.06-19.25-46.47c-12.41-12.42-28.91-19.25-46.47-19.25
                                c-0.03,0-0.07,0-0.11,0c-17.25,0.02-34.39,7.28-47.01,19.9l-237.24,237.24c-9.12,9.12-14.14,21.24-14.14,34.14
                                s5.02,25.03,14.14,34.15c18.83,18.82,49.46,18.82,68.29,0l219.34-219.34c6.68-6.68,9.84-15.95,8.69-25.44
                                c-0.66-5.38-2.77-10.47-6.11-14.74c-5.89-7.54-14.69-11.86-24.14-11.86c-8.14,0-15.79,3.17-21.55,8.93l-142.69,142.69
                                c-5.65,5.65-14.85,5.65-20.51,0c-5.65-5.66-5.65-14.85,0-20.51l142.06-142.05c11.62-11.62,27.44-18.19,43.26-18.05
                                c15.67,0.14,30.41,6.33,41.49,17.42c11.09,11.08,17.27,25.81,17.42,41.48c0.15,15.87-6.43,31.64-18.05,43.27l-218.71,218.7
                                c-14.57,14.58-33.98,22.61-54.65,22.61c-21.75,0-42.61-9.23-57.24-25.33c-12.08-13.29-19.17-30.49-19.97-48.41
                                c-0.97-21.99,7.05-42.65,22.56-58.17l237.9-237.89c17.89-17.89,41.67-27.74,66.97-27.74
                                C352.809,12.323,376.599,22.173,394.489,40.063z" />
                                </g>
                            </g>
                        </g>

                    </svg>
                    <p class="leading-none"> &nbsp; 26.11.2020, 10:10 Uhr</p>
                </div>
            </div>
        </div>

        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <img src="https://source.unsplash.com/random" alt="People" class="w-full object-cover h-32 sm:h-48 md:h-64" />
            <div class="p-4 md:p-6 bg-white flex flex-col flex-1">
                <p class="text-blue-500 font-semibold text-xs mb-1 leading-none">Business Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby Business Application</h3>
                </a>
                <div class="text-sm flex items-center">
                    <svg class="opacity-75 mr-2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="12" height="12" viewBox="0 0 97.16 97.16" style="enable-background: new 0 0 97.16 97.16;" xml:space="preserve">
                        <path d="M48.58,0C21.793,0,0,21.793,0,48.58s21.793,48.58,48.58,48.58s48.58-21.793,48.58-48.58S75.367,0,48.58,0z M48.58,86.823    c-21.087,0-38.244-17.155-38.244-38.243S27.493,10.337,48.58,10.337S86.824,27.492,86.824,48.58S69.667,86.823,48.58,86.823z"></path>
                        <path d="M73.898,47.08H52.066V20.83c0-2.209-1.791-4-4-4c-2.209,0-4,1.791-4,4v30.25c0,2.209,1.791,4,4,4h25.832    c2.209,0,4-1.791,4-4S76.107,47.08,73.898,47.08z"></path>
                    </svg>
                    <p class="leading-none">26.11.2020, 10:10 Uhr</p>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="grid grid-cols-1 divide-y divide-gray-100">
    <div> </div>
    <div>
    </div>
</div>

<div class="pt-10">
    <h1 class="text-4xl font-normal leading-normal mt-0 mb-2 text-black-800 text-center">
        Client Testimonial!
    </h1>

</div>

<div class="container mx-auto">
    <div class="flex flex-col sm:flex-row justify-between mx-4 md:mx-0 lg:-mx-2 flex-wrap">
        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <img src="https://source.unsplash.com/random" alt="product" class="w-full object-cover h-32 sm:h-48 md:h-64" />
            <div class="p-4 md:p-6 bg-white flex flex-col flex-1">
                <p class="text-blue-500 font-semibold text-xs mb-1 leading-none">User Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby</h3>
                </a>
                <div class="text-sm flex items-center">

                    <svg version="1.1" width="20px" height="20px" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 422.186 422.186" style="enable-background:new 0 0 422.186 422.186;" xml:space="preserve">
                        <g>
                            <g id="XMLID_14_">
                                <g>
                                    <path style="fill:#A7B6C4;" d="M134.729,242.243c-1.47,0-2.85-0.58-3.89-1.62c-1.04-1.03-1.61-2.42-1.61-3.88
                                c0-1.47,0.57-2.86,1.61-3.89l142.05-142.06c9.82-9.81,23.05-15.42,36.38-15.42c0.14,0,0.29,0,0.44,0.01
                                c13.3,0.12,25.8,5.37,35.21,14.78s14.66,21.91,14.78,35.2c0.13,13.48-5.49,26.9-15.41,36.82l-218.71,218.71
                                c-12.88,12.87-30.02,19.97-48.29,19.97c-19.22,0-37.65-8.16-50.58-22.38c-10.67-11.74-16.94-26.93-17.63-42.76
                                c-0.86-19.44,6.22-37.69,19.93-51.4l237.89-237.9c16.19-16.19,37.72-25.1,60.61-25.1c22.9,0,44.42,8.91,60.61,25.1
                                c33.42,33.43,33.42,87.81,0,121.23l-161.24,161.24c-1.04,1.04-2.42,1.61-3.89,1.61s-2.85-0.57-3.89-1.61
                                c-1.04-1.04-1.61-2.42-1.61-3.89s0.57-2.85,1.61-3.89l161.24-161.24c14.12-14.11,21.89-32.88,21.89-52.83
                                c0-19.96-7.77-38.73-21.89-52.84c-14.11-14.11-32.87-21.88-52.83-21.88c-0.04,0-0.08,0-0.12,0
                                c-19.62,0.03-39.07,8.24-53.36,22.53l-237.24,237.24c-10.82,10.82-16.78,25.21-16.78,40.51s5.96,29.69,16.78,40.51
                                c11.16,11.17,25.83,16.75,40.5,16.75s29.35-5.58,40.51-16.75l219.34-219.34c8.65-8.65,12.76-20.64,11.26-32.89
                                c-0.85-7-3.6-13.64-7.95-19.2c-7.6-9.73-18.99-15.31-31.23-15.31c-10.54,0-20.46,4.11-27.92,11.57l-142.68,142.68
                                C137.579,241.663,136.199,242.243,134.729,242.243z" />
                                    <path d="M130.839,240.623c1.04,1.04,2.42,1.62,3.89,1.62s2.85-0.58,3.89-1.62l142.68-142.68c7.46-7.46,17.38-11.57,27.92-11.57
                                c12.24,0,23.63,5.58,31.23,15.31c4.35,5.56,7.1,12.2,7.95,19.2c1.5,12.25-2.61,24.24-11.26,32.89l-219.34,219.34
                                c-11.16,11.17-25.84,16.75-40.51,16.75s-29.34-5.58-40.5-16.75c-10.82-10.82-16.78-25.21-16.78-40.51s5.96-29.69,16.78-40.51
                                l237.24-237.24c14.29-14.29,33.74-22.5,53.36-22.53c0.04,0,0.08,0,0.12,0c19.96,0,38.72,7.77,52.83,21.88
                                c14.12,14.11,21.89,32.88,21.89,52.84c0,19.95-7.77,38.72-21.89,52.83l-161.24,161.24c-1.04,1.04-1.61,2.42-1.61,3.89
                                s0.57,2.85,1.61,3.89c1.04,1.04,2.42,1.61,3.89,1.61s2.85-0.57,3.89-1.61l161.24-161.24c33.42-33.42,33.42-87.8,0-121.23
                                c-16.19-16.19-37.71-25.1-60.61-25.1c-22.89,0-44.42,8.91-60.61,25.1l-237.89,237.9c-13.71,13.71-20.79,31.96-19.93,51.4
                                c0.69,15.83,6.96,31.02,17.63,42.76c12.93,14.22,31.36,22.38,50.58,22.38c18.27,0,35.41-7.1,48.29-19.97l218.71-218.71
                                c9.92-9.92,15.54-23.34,15.41-36.82c-0.12-13.29-5.37-25.79-14.78-35.2s-21.91-14.66-35.21-14.78c-0.15-0.01-0.3-0.01-0.44-0.01
                                c-13.33,0-26.56,5.61-36.38,15.42l-142.05,142.06c-1.04,1.03-1.61,2.42-1.61,3.89
                                C129.229,238.203,129.799,239.593,130.839,240.623z M394.489,40.063c36.93,36.93,36.93,97.02,0,133.95l-161.25,161.24
                                c-2.73,2.74-6.38,4.25-10.25,4.25c-3.87,0-7.51-1.51-10.25-4.25c-2.74-2.73-4.25-6.38-4.25-10.25s1.51-7.51,4.25-10.25
                                l161.24-161.24c12.41-12.42,19.25-28.92,19.25-46.47c0-17.56-6.84-34.06-19.25-46.47c-12.41-12.42-28.91-19.25-46.47-19.25
                                c-0.03,0-0.07,0-0.11,0c-17.25,0.02-34.39,7.28-47.01,19.9l-237.24,237.24c-9.12,9.12-14.14,21.24-14.14,34.14
                                s5.02,25.03,14.14,34.15c18.83,18.82,49.46,18.82,68.29,0l219.34-219.34c6.68-6.68,9.84-15.95,8.69-25.44
                                c-0.66-5.38-2.77-10.47-6.11-14.74c-5.89-7.54-14.69-11.86-24.14-11.86c-8.14,0-15.79,3.17-21.55,8.93l-142.69,142.69
                                c-5.65,5.65-14.85,5.65-20.51,0c-5.65-5.66-5.65-14.85,0-20.51l142.06-142.05c11.62-11.62,27.44-18.19,43.26-18.05
                                c15.67,0.14,30.41,6.33,41.49,17.42c11.09,11.08,17.27,25.81,17.42,41.48c0.15,15.87-6.43,31.64-18.05,43.27l-218.71,218.7
                                c-14.57,14.58-33.98,22.61-54.65,22.61c-21.75,0-42.61-9.23-57.24-25.33c-12.08-13.29-19.17-30.49-19.97-48.41
                                c-0.97-21.99,7.05-42.65,22.56-58.17l237.9-237.89c17.89-17.89,41.67-27.74,66.97-27.74
                                C352.809,12.323,376.599,22.173,394.489,40.063z" />
                                </g>
                            </g>
                        </g>

                    </svg>
                    <p class="leading-none"> &nbsp; 26.11.2020, 10:10 Uhr</p>
                </div>
            </div>
        </div>

        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <img src="https://source.unsplash.com/random" alt="product" class="w-full object-cover h-32 sm:h-48 md:h-64" />
            <div class="p-4 md:p-6 bg-white flex flex-col flex-1">
                <p class="text-blue-500 font-semibold text-xs mb-1 leading-none">User Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby</h3>
                </a>
                <div class="text-sm flex items-center">

                    <svg version="1.1" width="20px" height="20px" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 422.186 422.186" style="enable-background:new 0 0 422.186 422.186;" xml:space="preserve">
                        <g>
                            <g id="XMLID_14_">
                                <g>
                                    <path style="fill:#A7B6C4;" d="M134.729,242.243c-1.47,0-2.85-0.58-3.89-1.62c-1.04-1.03-1.61-2.42-1.61-3.88
                                c0-1.47,0.57-2.86,1.61-3.89l142.05-142.06c9.82-9.81,23.05-15.42,36.38-15.42c0.14,0,0.29,0,0.44,0.01
                                c13.3,0.12,25.8,5.37,35.21,14.78s14.66,21.91,14.78,35.2c0.13,13.48-5.49,26.9-15.41,36.82l-218.71,218.71
                                c-12.88,12.87-30.02,19.97-48.29,19.97c-19.22,0-37.65-8.16-50.58-22.38c-10.67-11.74-16.94-26.93-17.63-42.76
                                c-0.86-19.44,6.22-37.69,19.93-51.4l237.89-237.9c16.19-16.19,37.72-25.1,60.61-25.1c22.9,0,44.42,8.91,60.61,25.1
                                c33.42,33.43,33.42,87.81,0,121.23l-161.24,161.24c-1.04,1.04-2.42,1.61-3.89,1.61s-2.85-0.57-3.89-1.61
                                c-1.04-1.04-1.61-2.42-1.61-3.89s0.57-2.85,1.61-3.89l161.24-161.24c14.12-14.11,21.89-32.88,21.89-52.83
                                c0-19.96-7.77-38.73-21.89-52.84c-14.11-14.11-32.87-21.88-52.83-21.88c-0.04,0-0.08,0-0.12,0
                                c-19.62,0.03-39.07,8.24-53.36,22.53l-237.24,237.24c-10.82,10.82-16.78,25.21-16.78,40.51s5.96,29.69,16.78,40.51
                                c11.16,11.17,25.83,16.75,40.5,16.75s29.35-5.58,40.51-16.75l219.34-219.34c8.65-8.65,12.76-20.64,11.26-32.89
                                c-0.85-7-3.6-13.64-7.95-19.2c-7.6-9.73-18.99-15.31-31.23-15.31c-10.54,0-20.46,4.11-27.92,11.57l-142.68,142.68
                                C137.579,241.663,136.199,242.243,134.729,242.243z" />
                                    <path d="M130.839,240.623c1.04,1.04,2.42,1.62,3.89,1.62s2.85-0.58,3.89-1.62l142.68-142.68c7.46-7.46,17.38-11.57,27.92-11.57
                                c12.24,0,23.63,5.58,31.23,15.31c4.35,5.56,7.1,12.2,7.95,19.2c1.5,12.25-2.61,24.24-11.26,32.89l-219.34,219.34
                                c-11.16,11.17-25.84,16.75-40.51,16.75s-29.34-5.58-40.5-16.75c-10.82-10.82-16.78-25.21-16.78-40.51s5.96-29.69,16.78-40.51
                                l237.24-237.24c14.29-14.29,33.74-22.5,53.36-22.53c0.04,0,0.08,0,0.12,0c19.96,0,38.72,7.77,52.83,21.88
                                c14.12,14.11,21.89,32.88,21.89,52.84c0,19.95-7.77,38.72-21.89,52.83l-161.24,161.24c-1.04,1.04-1.61,2.42-1.61,3.89
                                s0.57,2.85,1.61,3.89c1.04,1.04,2.42,1.61,3.89,1.61s2.85-0.57,3.89-1.61l161.24-161.24c33.42-33.42,33.42-87.8,0-121.23
                                c-16.19-16.19-37.71-25.1-60.61-25.1c-22.89,0-44.42,8.91-60.61,25.1l-237.89,237.9c-13.71,13.71-20.79,31.96-19.93,51.4
                                c0.69,15.83,6.96,31.02,17.63,42.76c12.93,14.22,31.36,22.38,50.58,22.38c18.27,0,35.41-7.1,48.29-19.97l218.71-218.71
                                c9.92-9.92,15.54-23.34,15.41-36.82c-0.12-13.29-5.37-25.79-14.78-35.2s-21.91-14.66-35.21-14.78c-0.15-0.01-0.3-0.01-0.44-0.01
                                c-13.33,0-26.56,5.61-36.38,15.42l-142.05,142.06c-1.04,1.03-1.61,2.42-1.61,3.89
                                C129.229,238.203,129.799,239.593,130.839,240.623z M394.489,40.063c36.93,36.93,36.93,97.02,0,133.95l-161.25,161.24
                                c-2.73,2.74-6.38,4.25-10.25,4.25c-3.87,0-7.51-1.51-10.25-4.25c-2.74-2.73-4.25-6.38-4.25-10.25s1.51-7.51,4.25-10.25
                                l161.24-161.24c12.41-12.42,19.25-28.92,19.25-46.47c0-17.56-6.84-34.06-19.25-46.47c-12.41-12.42-28.91-19.25-46.47-19.25
                                c-0.03,0-0.07,0-0.11,0c-17.25,0.02-34.39,7.28-47.01,19.9l-237.24,237.24c-9.12,9.12-14.14,21.24-14.14,34.14
                                s5.02,25.03,14.14,34.15c18.83,18.82,49.46,18.82,68.29,0l219.34-219.34c6.68-6.68,9.84-15.95,8.69-25.44
                                c-0.66-5.38-2.77-10.47-6.11-14.74c-5.89-7.54-14.69-11.86-24.14-11.86c-8.14,0-15.79,3.17-21.55,8.93l-142.69,142.69
                                c-5.65,5.65-14.85,5.65-20.51,0c-5.65-5.66-5.65-14.85,0-20.51l142.06-142.05c11.62-11.62,27.44-18.19,43.26-18.05
                                c15.67,0.14,30.41,6.33,41.49,17.42c11.09,11.08,17.27,25.81,17.42,41.48c0.15,15.87-6.43,31.64-18.05,43.27l-218.71,218.7
                                c-14.57,14.58-33.98,22.61-54.65,22.61c-21.75,0-42.61-9.23-57.24-25.33c-12.08-13.29-19.17-30.49-19.97-48.41
                                c-0.97-21.99,7.05-42.65,22.56-58.17l237.9-237.89c17.89-17.89,41.67-27.74,66.97-27.74
                                C352.809,12.323,376.599,22.173,394.489,40.063z" />
                                </g>
                            </g>
                        </g>

                    </svg>
                    <p class="leading-none"> &nbsp; 26.11.2020, 10:10 Uhr</p>
                </div>
            </div>
        </div>

        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <img src="https://source.unsplash.com/random" alt="product" class="w-full object-cover h-32 sm:h-48 md:h-64" />
            <div class="p-4 md:p-6 bg-white flex flex-col flex-1">
                <p class="text-blue-500 font-semibold text-xs mb-1 leading-none">User Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby</h3>
                </a>
                <div class="text-sm flex items-center">

                    <svg version="1.1" width="20px" height="20px" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 422.186 422.186" style="enable-background:new 0 0 422.186 422.186;" xml:space="preserve">
                        <g>
                            <g id="XMLID_14_">
                                <g>
                                    <path style="fill:#A7B6C4;" d="M134.729,242.243c-1.47,0-2.85-0.58-3.89-1.62c-1.04-1.03-1.61-2.42-1.61-3.88
                                c0-1.47,0.57-2.86,1.61-3.89l142.05-142.06c9.82-9.81,23.05-15.42,36.38-15.42c0.14,0,0.29,0,0.44,0.01
                                c13.3,0.12,25.8,5.37,35.21,14.78s14.66,21.91,14.78,35.2c0.13,13.48-5.49,26.9-15.41,36.82l-218.71,218.71
                                c-12.88,12.87-30.02,19.97-48.29,19.97c-19.22,0-37.65-8.16-50.58-22.38c-10.67-11.74-16.94-26.93-17.63-42.76
                                c-0.86-19.44,6.22-37.69,19.93-51.4l237.89-237.9c16.19-16.19,37.72-25.1,60.61-25.1c22.9,0,44.42,8.91,60.61,25.1
                                c33.42,33.43,33.42,87.81,0,121.23l-161.24,161.24c-1.04,1.04-2.42,1.61-3.89,1.61s-2.85-0.57-3.89-1.61
                                c-1.04-1.04-1.61-2.42-1.61-3.89s0.57-2.85,1.61-3.89l161.24-161.24c14.12-14.11,21.89-32.88,21.89-52.83
                                c0-19.96-7.77-38.73-21.89-52.84c-14.11-14.11-32.87-21.88-52.83-21.88c-0.04,0-0.08,0-0.12,0
                                c-19.62,0.03-39.07,8.24-53.36,22.53l-237.24,237.24c-10.82,10.82-16.78,25.21-16.78,40.51s5.96,29.69,16.78,40.51
                                c11.16,11.17,25.83,16.75,40.5,16.75s29.35-5.58,40.51-16.75l219.34-219.34c8.65-8.65,12.76-20.64,11.26-32.89
                                c-0.85-7-3.6-13.64-7.95-19.2c-7.6-9.73-18.99-15.31-31.23-15.31c-10.54,0-20.46,4.11-27.92,11.57l-142.68,142.68
                                C137.579,241.663,136.199,242.243,134.729,242.243z" />
                                    <path d="M130.839,240.623c1.04,1.04,2.42,1.62,3.89,1.62s2.85-0.58,3.89-1.62l142.68-142.68c7.46-7.46,17.38-11.57,27.92-11.57
                                c12.24,0,23.63,5.58,31.23,15.31c4.35,5.56,7.1,12.2,7.95,19.2c1.5,12.25-2.61,24.24-11.26,32.89l-219.34,219.34
                                c-11.16,11.17-25.84,16.75-40.51,16.75s-29.34-5.58-40.5-16.75c-10.82-10.82-16.78-25.21-16.78-40.51s5.96-29.69,16.78-40.51
                                l237.24-237.24c14.29-14.29,33.74-22.5,53.36-22.53c0.04,0,0.08,0,0.12,0c19.96,0,38.72,7.77,52.83,21.88
                                c14.12,14.11,21.89,32.88,21.89,52.84c0,19.95-7.77,38.72-21.89,52.83l-161.24,161.24c-1.04,1.04-1.61,2.42-1.61,3.89
                                s0.57,2.85,1.61,3.89c1.04,1.04,2.42,1.61,3.89,1.61s2.85-0.57,3.89-1.61l161.24-161.24c33.42-33.42,33.42-87.8,0-121.23
                                c-16.19-16.19-37.71-25.1-60.61-25.1c-22.89,0-44.42,8.91-60.61,25.1l-237.89,237.9c-13.71,13.71-20.79,31.96-19.93,51.4
                                c0.69,15.83,6.96,31.02,17.63,42.76c12.93,14.22,31.36,22.38,50.58,22.38c18.27,0,35.41-7.1,48.29-19.97l218.71-218.71
                                c9.92-9.92,15.54-23.34,15.41-36.82c-0.12-13.29-5.37-25.79-14.78-35.2s-21.91-14.66-35.21-14.78c-0.15-0.01-0.3-0.01-0.44-0.01
                                c-13.33,0-26.56,5.61-36.38,15.42l-142.05,142.06c-1.04,1.03-1.61,2.42-1.61,3.89
                                C129.229,238.203,129.799,239.593,130.839,240.623z M394.489,40.063c36.93,36.93,36.93,97.02,0,133.95l-161.25,161.24
                                c-2.73,2.74-6.38,4.25-10.25,4.25c-3.87,0-7.51-1.51-10.25-4.25c-2.74-2.73-4.25-6.38-4.25-10.25s1.51-7.51,4.25-10.25
                                l161.24-161.24c12.41-12.42,19.25-28.92,19.25-46.47c0-17.56-6.84-34.06-19.25-46.47c-12.41-12.42-28.91-19.25-46.47-19.25
                                c-0.03,0-0.07,0-0.11,0c-17.25,0.02-34.39,7.28-47.01,19.9l-237.24,237.24c-9.12,9.12-14.14,21.24-14.14,34.14
                                s5.02,25.03,14.14,34.15c18.83,18.82,49.46,18.82,68.29,0l219.34-219.34c6.68-6.68,9.84-15.95,8.69-25.44
                                c-0.66-5.38-2.77-10.47-6.11-14.74c-5.89-7.54-14.69-11.86-24.14-11.86c-8.14,0-15.79,3.17-21.55,8.93l-142.69,142.69
                                c-5.65,5.65-14.85,5.65-20.51,0c-5.65-5.66-5.65-14.85,0-20.51l142.06-142.05c11.62-11.62,27.44-18.19,43.26-18.05
                                c15.67,0.14,30.41,6.33,41.49,17.42c11.09,11.08,17.27,25.81,17.42,41.48c0.15,15.87-6.43,31.64-18.05,43.27l-218.71,218.7
                                c-14.57,14.58-33.98,22.61-54.65,22.61c-21.75,0-42.61-9.23-57.24-25.33c-12.08-13.29-19.17-30.49-19.97-48.41
                                c-0.97-21.99,7.05-42.65,22.56-58.17l237.9-237.89c17.89-17.89,41.67-27.74,66.97-27.74
                                C352.809,12.323,376.599,22.173,394.489,40.063z" />
                                </g>
                            </g>
                        </g>

                    </svg>
                    <p class="leading-none"> &nbsp; 26.11.2020, 10:10 Uhr</p>
                </div>
            </div>
        </div>

        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <img src="https://source.unsplash.com/random" alt="People" class="w-full object-cover h-32 sm:h-48 md:h-64" />
            <div class="p-4 md:p-6 bg-white flex flex-col flex-1">
                <p class="text-blue-500 font-semibold text-xs mb-1 leading-none">Business Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby Business Application</h3>
                </a>
                <div class="text-sm flex items-center">
                    <svg class="opacity-75 mr-2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="12" height="12" viewBox="0 0 97.16 97.16" style="enable-background: new 0 0 97.16 97.16;" xml:space="preserve">
                        <path d="M48.58,0C21.793,0,0,21.793,0,48.58s21.793,48.58,48.58,48.58s48.58-21.793,48.58-48.58S75.367,0,48.58,0z M48.58,86.823    c-21.087,0-38.244-17.155-38.244-38.243S27.493,10.337,48.58,10.337S86.824,27.492,86.824,48.58S69.667,86.823,48.58,86.823z"></path>
                        <path d="M73.898,47.08H52.066V20.83c0-2.209-1.791-4-4-4c-2.209,0-4,1.791-4,4v30.25c0,2.209,1.791,4,4,4h25.832    c2.209,0,4-1.791,4-4S76.107,47.08,73.898,47.08z"></path>
                    </svg>
                    <p class="leading-none">26.11.2020, 10:10 Uhr</p>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="grid grid-cols-1 divide-y divide-gray-100">
    <div> </div>
    <div>
    </div>
</div>

<div class="pt-10">
    <h1 class="text-4xl font-normal leading-normal mt-0 mb-2 text-black-800 text-center">
        Product and Services
    </h1>

</div>

<div class="container mx-auto">
    <div class="flex flex-col  sm:flex-row justify-between mx-4 md:mx-0 lg:-mx-2 flex-wrap">

        <div class="rounded overflow-hidden shadow-lg flex-1 bg-white sm:mx-2 md:mx-1 lg:mx-2 w-full sm:w-1/3 lg:pt-0 border-b-4 border-blue-500 mb-10 flex flex-col">
            <div class="p-4 md:p-6 bg-black text-white flex flex-col flex-1 ">
                <p class="text-white-500 font-semibold text-5xl mb-1 leading-none">Business Application</p>
                <a href="http://example.test/2020/11/26/hello-world/" class="flex-1">
                    <h3 class="font-semibold mb-2 text-xl leading-tight sm:leading-normal">Passerby Business Application</h3>
                </a>
                <div class="text-sm flex items-center">
                    <svg class="opacity-75 mr-2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="12" height="12" viewBox="0 0 97.16 97.16" style="enable-background: new 0 0 97.16 97.16;" xml:space="preserve">
                        <path d="M48.58,0C21.793,0,0,21.793,0,48.58s21.793,48.58,48.58,48.58s48.58-21.793,48.58-48.58S75.367,0,48.58,0z M48.58,86.823    c-21.087,0-38.244-17.155-38.244-38.243S27.493,10.337,48.58,10.337S86.824,27.492,86.824,48.58S69.667,86.823,48.58,86.823z"></path>
                        <path d="M73.898,47.08H52.066V20.83c0-2.209-1.791-4-4-4c-2.209,0-4,1.791-4,4v30.25c0,2.209,1.791,4,4,4h25.832    c2.209,0,4-1.791,4-4S76.107,47.08,73.898,47.08z"></path>
                    </svg>
                    <p class="leading-none">26.11.2020, 10:10 Uhr</p>
                </div>
                <br>
                <br>
                <br>

            </div>

            <img src="/static/img/swiss-watches-black-background.jpg" alt="People" class="w-full object-cover h-32 sm:h-48 md:h-64" />

        </div>

    </div>
</div>

<div class="grid grid-cols-1 divide-y divide-gray-100">
    <div> </div>
    <div>
    </div>
</div>




                <div class="container mx-auto pt-16">
                    <div class="pb-12">
                        <h1 class="text-3xl xl:text-5xl font-extrabold text-gray-800 mx-auto text-center xl:text-left mb-4">Hear From Our Customers</h1>
                        <p class="text-xl text-gray-600 xl:w-3/4 w-11/12 mx-auto xl:mx-0 text-center sm:text-left">I just wanted to share a quick note and let you know that you guys do a really good job. I’m glad I decided to work with you. It’s really great how easy your websites are to update and manage.</p>
                    </div>
                    <section id="carousel">
                        <figure class="visible">
                            <div class="flex flex-wrap justify-around">
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:pb-0 pb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Alex Parkinson</h1>
                                            <p class="text-base text-indigo-200">AlphaSquad LLC</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1566753323558-f4e0952af115.jfif" alt="Display Avatar of Alex Parkinson" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Ashley Wilson</h1>
                                            <p class="text-base text-indigo-200">i-Intellect Inc</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1548958921-c5c0fe1b307d.jfif" alt="Display Avatar of Ashley Wilson" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Richard Clark</h1>
                                            <p class="text-base text-indigo-200">Apple Inc</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1564061170517-d3907caa96ea.jfif" alt="Display Avatar of Richard Clark" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </figure>
                        <figure class="hidden">
                            <div class="flex flex-wrap justify-around">
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Ashley Wilson</h1>
                                            <p class="text-base text-indigo-200">i-Intellect Inc</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1548958921-c5c0fe1b307d.jfif" alt="Display Avatar of Ashley Wilson" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:pb-0 pb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Alex Parkinson</h1>
                                            <p class="text-base text-indigo-200">AlphaSquad LLC</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1566753323558-f4e0952af115.jfif" alt="Display Avatar of Alex Parkinson" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Richard Clark</h1>
                                            <p class="text-base text-indigo-200">Apple Inc</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1564061170517-d3907caa96ea.jfif" alt="Display Avatar of Richard Clark" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </figure>
                        <figure class="hidden">
                            <div class="flex flex-wrap justify-around">
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Richard Clark</h1>
                                            <p class="text-base text-indigo-200">Apple Inc</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1564061170517-d3907caa96ea.jfif" alt="Display Avatar of Richard Clark" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:pb-0 pb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Alex Parkinson</h1>
                                            <p class="text-base text-indigo-200">AlphaSquad LLC</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1566753323558-f4e0952af115.jfif" alt="Display Avatar of Alex Parkinson" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                                            <h1 class="text-xl text-white pb-1">Ashley Wilson</h1>
                                            <p class="text-base text-indigo-200">i-Intellect Inc</p>
                                        </div>
                                        <div class="pl-6 pr-6 pt-10 relative h-64">
                                            <div class="h-16 w-16 rounded-full bg-cover border-4 border-white absolute top-0 right-0 -mt-8 mr-6">
                                                <img src="https://cdn.tuk.dev/assets/photo-1548958921-c5c0fe1b307d.jfif" alt="Display Avatar of Ashley Wilson" role="img" class="h-full w-full object-cover rounded-full overflow-hidden" />
                                            </div>

                                            <p class="text-base text-gray-600 leading-8">It really saves me time and effort. Chamer is exactly what our business has been lacking. Chamer was worth a fortune to my company.</p>
                                            <div class="flex justify-end mt-2">
                                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z"
                                                        fill="#667EEA"
                                                        fill-rule="evenodd"
                                                        fill-opacity=".15"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </figure>
                    </section>
                    <div class="cursor-pointer flex justify-center pt-4 pb-8 sm:pt-8 md:pt-8 lg:pt-8 xl:pt-12">
                        <button aria-label="Move To previous Testimonials" role="button" @click="movePrev" class="focus:outline-none focus:ring-2 focus:ring-gray-400 rounded">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-left" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#CBD5E0" fill="none" stroke-linecap="round" stroke-linejoin="round" @click="movePrev()">
                                <path stroke="none" d="M0 0h24v24H0z" />
                                <polyline points="15 6 9 12 15 18" />
                            </svg>
                        </button>
                        <button aria-label="Move to Next Testimonials" role="button" @click="moveForward" class="focus:outline-none focus:ring-2 focus:ring-gray-400 rounded">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-right" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#CBD5E0" fill="none" stroke-linecap="round" stroke-linejoin="round" @click="moveForward()">
                                <path stroke="none" d="M0 0h24v24H0z" />
                                <polyline points="9 6 15 12 9 18" />
                            </svg>
                        </button>
                    </div>
                </div>
               
            

</template>

<script> 
export default {
    name: 'NewProduct',
    
     data() {
         return {
             current: 0,
         }
     },
        methods: {
            
        getFigures() {
            return document.getElementById("carousel").getElementsByTagName("figure");
        },
        moveForward() {
            var pointer = 0;
            var figures = this.getFigures();
            for (var i = 0; i < figures.length; i++) {
                if (figures[i].className == "visible") {
                    figures[i].className = "hidden";
                    pointer = i;
                    this.$data.current = pointer + 1;
                }
            }
            if (++pointer == figures.length) {
                pointer = 0;
            }
            figures[pointer].className = "visible";
        },
        movePrev() {
            var figures = this.getFigures();
            for (var i = 0; i < figures.length; i++) {
                if (figures[i].className == "visible") {
                    figures[i].className = "hidden";
                }
            }
            if (this.$data.current === 0) {
                this.$data.current = figures.length - 1;
                figures[this.$data.current].className = "visible";
            } else {
                this.$data.current = this.$data.current - 1;
                figures[this.$data.current].className = "visible";
            }
        },
    }   
}

</script> 



 <style>
                    section#carousel > figure > div {
                        display: none;
                    }
                    section#carousel > figure.visible > div {
                        display: flex;
                        position: relative;
                    }
                </style>
                
