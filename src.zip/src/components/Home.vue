<template>
<div class=" bg-contain bg-center bg-gradient-to-b from-purple-600 to-purple-500 ">
     <!-- <div class="bg-yellow-600 w-72 h-72 rotate left-10  z-90 absolute opacity-50"></div> -->
     <!-- <div class=" square left-10 top-10 z-90 absolute opacity-50" style="border:20px solid red; width:200px; height:300px; "></div> -->
     <!-- <div class=" rotate-12 square rounded-full text-center text-white left-10 -top-12  z-90 absolute font-extrabold opacity-30" style=" solid red; width:80px; height:40px;  font-size:200px;  backdrop-filter:blur(2px)">FYRA
     </div> -->
         <!-- <div class=" rounded-full text-white absolute font-extrabold  text-right opacity-30" style=" width:80px; height:40px;  font-size:100px; top:1110px; right:1px  backdrop-filter:blur(2px)">Now Go <br> Online
     </div> -->

 <div class="w-full h-screen bg-gray-200">
<div>
    <div class="w-96 top-20 h-4/5 absolute right-1 "> <svg id="visual" viewBox="0 0 960 540" width="" height="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"><g transform="translate(394.6700127415268 205.73521185929957)"><path d="M142.9 -165.4C206.5 -150.5 293.9 -137.2 338.3 -89.1C382.6 -40.9 383.9 42.1 354.8 110.2C325.8 178.4 266.3 231.6 202.1 270.7C137.9 309.8 69 334.9 2.3 331.8C-64.5 328.7 -128.9 297.4 -163.2 248.6C-197.4 199.7 -201.4 133.2 -203.1 77.8C-204.8 22.5 -204.2 -21.8 -193.5 -65.5C-182.9 -109.1 -162.3 -152 -128.4 -176.5C-94.4 -201 -47.2 -207 -3.8 -201.8C39.7 -196.6 79.4 -180.2 142.9 -165.4" fill="#aba08c"></path></g></svg></div>
    <div class="grid grid-cols-2">
          <div class="relative w-full left-20 top-20 h-96">
    <!-- <div class="bg-green-600 w-96 h-96 rotate right-10  rounded-full -z-10 absolute opacity-25"></div>
    <div class="bg-yellow-600 w-72 h-72 rotate right-10 rounded-full -z-10 absolute opacity-25"></div> -->
        <div class="md:p-2 align-middle">
            <!--  <h1 class="text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-green-300 h-auto"> -->
            <h1 class=" sm:text-3xl md:text-6xl head text-2xl text-black m-2">
  <span>There </span>
  <span>are </span>
  <span>no </span>
  <span>limits </span>
  <span>to </span>
  <span>what </span>
  <span>you </span>
  <span>can </span>
  <span>accomplish, </span>
  <span>except </span>
  <span>the </span>
  <span>limits </span>
  <span>you </span>
  <span>place </span>
  <span>on</span>
  <span>your</span>
  <span>own</span>
  <span>thinking.</span>
</h1>

        </div>
    </div>
    </div>
</div>
    <div class="wave ">
    <div class="custom-shape-divider-bottom-1643726750">
    <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
        <path d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z" class="shape-fill"></path>
    </svg>
</div>
</div>
    </div>
 <div class="w-full h-60 text-center m-auto p-14">
     <h2 class="sentence w-full h-40 text-4xl font-extrabold text-transparent bg-clip-text  bg-gradient-to-br from-yellow-400 to-red-300  mb-10" style="">
                    <span class="text-transparent md:text-6xl bg-clip-text bg-gradient-to-br from-yellow-400 to-red-300">we help you </span>
                    <div class="words words-1 m-0 bg-clip-text  w-full bg-gradient-to-br from-yellow-400 to-red-300">
                        <span class="md:text-6xl">Restaurants </span>
                        <span class="md:text-6xl">Grocery Stores</span>
                        <span class="md:text-6xl">Small and Medium Businesse</span>
                        <span class="md:text-6xl">Small Businesses</span>
                        <!-- <span class="text-8xl">wordpress</span>
                        <span class="text-8xl">happiness</span> -->
                    </div>
                </h2>
 </div>

<div class="
      grid
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
      lg: w-10/12
      border-1
      rounded-md
      lg:ml-24
      md:ml-40
      ml-8
    ">
    <div class="lg:col-span-3 ">
    <!-- <div class="bg-green-600 w-96 h-96 rotate right-10  rounded-full -z-10 absolute opacity-25"></div>
    <div class="bg-yellow-600 w-72 h-72 rotate right-10 rounded-full -z-10 absolute opacity-25"></div> -->
        <div class="md:p-2 align-middle">
            <!--  <h1 class="text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-green-300 h-auto"> -->
            <!-- <h1 class="text-5xl font-extrabold text-transparent bg-clip-text  bg-gradient-to-br from-yellow-400 to-red-300 " style="font-size: 100px; "> -->
              <!-- <h2 class="sentence w-full  align-middle h-40 text-4xl font-extrabold text-transparent bg-clip-text  bg-gradient-to-br from-yellow-400 to-red-300  mb-10" style="">
                    <span class="text-transparent text-6xl bg-clip-text bg-gradient-to-br from-yellow-400 to-red-300">we help you </span>
                    <div class="words words-1  m-0 bg-clip-text  bg-gradient-to-br from-yellow-400 to-red-300"><br>
                        <span class="text-6xl ">Restaurants </span>
                        <span class="text-6xl">Grocery Stores</span>
                        <span class="text-6xl">Small and Medium Businesse</span>
                        <span class="text-6xl">Small Businesses</span>
                        <span class="text-8xl">wordpress</span>
                        <span class="text-8xl">happiness</span> 
                    </div>
                </h2> -->

        </div>
        <!-- <div class="bg-yellow-600 w-full h-screen  rounded-2xl z-90 absolute opacity-50"></div> -->
    </div>
    <div class="lg:col-span-3 from-left ">
        <div class="md:p-2  shadow-lg bg-white bg-opacity-30 rounded-lg m-4 border " style="backdrop-filter: blur(2px);">
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            mt-4
            text-white
          " style="font-size: 20px">
                The world is moving to Home Delivery and E-Commerce is here to stay.
                We are here to become your <span class="font-bold " style="color: #FFFF00">ONLINE PARTNER</span>. We are aggregators of services to give you great customized
                solutions as per your needs. Join the <span class="font-bold" style="color: #FFFF00">Passerby Platform</span> today!
            </div>
            <br>
            <div class="
            text-center
            px-16
            leading-normal
            transform
            transition
            duration-500
            hover:scale-110
          " style="font-size: 16px">
                <a href="https://dashboard.passerby.in/register/">
                    <button class="
              mx-auto
              lg:mx-0
              hover:underline
              font-bold
              bg-white
              my-6
              py-4
              px-8
              shadow-lg
              focus:outline-none
              focus:shadow-outline
              transform
              transition
              hover:scale-105
              duration-300
              ease-in-out
              w-25
              h-10
              text-center
              btn
            ">
                <span class="text-xl  font-semibold text-yellow-300 text-center " data-title="REGISTER">REGISTER</span>
                    </button>
                </a> &nbsp; &nbsp;
                <a>this

                    <button class="
              mx-auto
              lg:mx-0
              hover:underline
              font-bold
             
              my-6
              py-4
              px-8
              shadow-lg
              focus:outline-none
              focus:shadow-outline
              transform
              transition
              hover:scale-105
              duration-300
              ease-in-out
              w-25
              text-center
              h-10
              btn
            ">
                       <span class=" font-semibold text-lg text-center  bg-transparent text-yellow-300" data-title="Send Enquiry">Send Enquiry</span>
                    </button>
                </a>
            </div>
        </div>
            <div class="
            mt-20
            text-center text-xl
            w-full
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            
            text-white
          " style="font-size: 14px;">
                <span class="font-extrabold text-6xl" style="color: #FFFF00">
                    The platform is ready to be used by
                </span>
                <div class="uvp-list flex justify-center flex-wrap text-black ">
                    <div class=""><div class="w-52 h-52  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500 shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <h1 class="text-lg font-bold p-2 ">Restaurants - Dine In and Home Delivery </h1>  <img class="w-20 h-20 ml-16" src="" alt="">
                         </div></div>
                    
                    <div class=""><div class="w-52 h-52  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 border-gray-600 hover:border-gray-800  hover:bg-white transform hover:scale-110 transition-all duration-500   shadow-lg rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold p-2 w-full">Grocery <br> Stores  </p> <img class="w-20 h-20 ml-16" src="https://ibb.co/JkzBBxb" alt=""> </div></div>
                   
                    <div class=""><div class="w-52 h-52  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500  shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold p-4 w-full">Small and Medium Sized Enterprises (SME's) </p> <img class="w-20 h-20 ml-16" src="https://ibb.co/3RHg9CB" alt=""> </div></div>
                   
                    <div class=""><div class="w-52 h-52  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500   shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold pt-8 w-full">Hyperlocal and E-Businesses </p> <img  class="w-20 h-20 ml-16" src="https://ibb.co/QPwqqj5" alt=""> </div></div>
                   
                    <!-- <ul>
                        <li>Restaurants - Dine In and Home Delivery </li>
                        <li>Grocery Stores </li>
                        <li>Small and Medium Sized Enterprises (SME's) </li>
                        <li>Hyperlocal and E-Businesses </li>
                    </ul> -->
                </div>
            
            <div class="
            mt-20
            text-center text-xl
            w-full
            leading-normal
            transform
            transition
            duration-500
            hover:scale-100
            px-5
            text-white
          " style="font-size: 14px;">
                <span class="font-extrabold text-6xl" style="color: #FFFF00">
                     The Passerby Platform consists of customized and business specific
                </span>
                <div class="uvp-list flex justify-center flex-wrap text-black ">
                    <div class=""><div class="w-52 h-52  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500 shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <h1 class="text-lg font-bold p-2 ">E-Commerce Web Application</h1>  <img class="w-20 h-20 ml-16" src="" alt="">
                         </div></div>
                    
                    <div class=""><div class="w-52 h-52  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 border-gray-600 hover:border-gray-800  hover:bg-white transform hover:scale-110 transition-all duration-500   shadow-lg rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold p-2 w-full">Mobile (Android and iOS) User Application  </p> <img class="w-20 h-20 ml-16" src="https://ibb.co/JkzBBxb" alt=""> </div></div>
                   
                    <div class=""><div class="w-52 h-52  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500  shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold p-4 w-full">Mobile Delivery Application </p> <img class="w-20 h-20 ml-16" src="https://ibb.co/3RHg9CB" alt=""> </div></div>
                   
                    <div class=""><div class="w-52 h-52  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500   shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold pt-8 w-full">Business Mobile Application </p> <img  class="w-20 h-20 ml-16" src="https://ibb.co/QPwqqj5" alt=""> </div></div>
                   
                    <!-- <ul>
                        <li>Restaurants - Dine In and Home Delivery </li>
                        <li>Grocery Stores </li>
                        <li>Small and Medium Sized Enterprises (SME's) </li>
                        <li>Hyperlocal and E-Businesses </li>
                    </ul> -->
                </div>
            

                <br>
                <!-- <span class="font-bold" style="color: #FFFF00">
                    The Passerby Platform consists of customized and business specific:
                </span>
                <div class="uvp-list">
                    <ul>
                        <li>E-Commerce Web Application, </li>
                        <li> Mobile (Android and iOS) User Application </li>
                        <li>Mobile Delivery Application and </li>
                        <li>Business Mobile Application. </li>
                    </ul> -->

                </div>
            </div>
            
    </div>

    <!-- <div class=" bg-blue-800 bg-opacity-30 rounded-lg from-right m-4" style="backdrop-filter:blur(10px);">
        <img src="https://fyra.biz/static/img/hero.png" class="mt-10" />
    </div> -->

</div>

<div class="
      grid
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
      lg: w-10/12
      border
      
      shadow-xl
      ml-8
      mt-3
    ">
    <div class="col-span-3  w-full bg-blue-800 shadow-lg bg-opacity-30 from-right " style="backdrop-filter:blur(3px);">
        <div class="md:p-1 flex flex-col flex-1">
            <h1 class="mt-5  mb-4 relative font-bold leading-tight text-center text-yellow-300" style="font-size: 48px">
               <span class="bottom-corner w-40">With Fyra Tick the Right Boxes!</span>
            </h1>

            <!--div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div-->
            <div class="
           
             text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
            w-full
            text-white
          " style="font-size:16px">
                Selling Online is only a part of it. Online presence is much more
                than that. Competition is everywhere, so marketing is important.
                There is a huge requirement of creating your own brand. There is no
                conventional sales team. In Digital World, marketing is not through
                conventional modes, but its through Digital media. You need to tick
                all the right boxes.

            </div>
            <div class="">

            <div class="container gap-8 ml-20 grid grid-cols-2 md:grid-rows-2 ">
                <div class=" col-span-1 md:col-span-1 sm:col-span-2 md:ml-20 md:-mt-2">
                    <div class="ml-20 w-32" ><h1 class="text-3xl relative  border-b-8"> <span class=" ">heading</span> </h1></div>
                <div class="w-72 h-96  hover:text-2xl rounded-2xl bg-white relative"> <div  class="layer"><h3 class="text-lg absolute bottom-1 left-20">heading <hr> <p class="">lorem lorem</p> </h3></div>
                </div>
                </div>
                <div>
                    <div class="col-span-1 md:col-span-1 sm:col-span-2" ><h1 class="text-3xl relative border-b-8 w-20"> <span class=" ">heading</span> </h1></div>
                <div class="w-72 h-96  hover:text-2xl rounded-2xl bg-white relative"> <div  class="layer"><h3 class="text-lg md:absolute bottom-1 md:left-20">heading <hr> <p class="">lorem lorem</p> </h3></div>
                </div>
                </div>
                   <div class="col-span-1 md:col-span-1 sm:col-span-2 md:-mt-4">
                    <div class="ml-20 w-32 " ><h1 class="text-3xl relative  border-b-8"> <span class=" ">heading</span> </h1></div>
                <div class="w-72 h-96 hover:text-2xl rounded-2xl bg-white relative"> <div  class="layer"><h3 class="text-lg md:absolute bottom-1 md:left-20">heading <hr> <p class="">lorem lorem</p> </h3></div>
                </div>
                </div>
               
                   <div class="col-span-1 md:col-span-1  sm:col-span-2  md:mt-10">
                    <div class="md:ml-20 w-32 " ><h1 class="text-3xl relative  border-b-8"> <span class=" ">heading</span> </h1></div>
                <div class="w-72 h-96 hover:text-2xl rounded-2xl bg-white relative"> <div  class="layer"><h3 class="text-lg absolute bottom-1 md:left-20">heading <hr> <p class="">lorem lorem</p> </h3></div>
                </div>
                </div>
               
               
                
            </div>
            </div>
  
        </div>
    </div>
  
</div>

<div class="
        w-10/12
        ml-20
      rounded-md
      shadow-xl
      p-8
      bg-blue-800 bg-opacity-30 rounded-lg
      border
      top-bottom
      mt-10
    " style="backdrop-filter:blur(3px);">
    <div class="flex flex-wrap justify-center space-x-10 w-full">

    <div class=" ">
                <!-- <div class=" px-8 pb-8 shadow-2xl rounded-lg bg-gray-100 text-center relative"> -->
                  <!-- <div class="absolute top-0 left-0 right-0 ">
                    <div class="inline-block bg-indigo-600 p-2 rounded-full transform -translate-y-1/2">
                    <div class="px-2 py-3 h-16 w-16">
  <span id="count1" class="display-4 text-2xl oldstyle-nums text-red-900">0</span>
<span class="text-xl font-bold">+</span>
  </div></div>
                  </div> -->
                  <!-- <div class="mt-10 uppercasec text-2xl text-indigo-700 font-extrabold">heading</div>
                  <div class="mt-2 text-base text-indigo-600">lorem lrorem kroerm
                  </div>
                </div>
    </div>
    <div class=" flex  max-w-sm pt-16">
                <div class=" px-8 pb-8 shadow-2xl rounded-lg bg-gray-100 text-center relative">
                  <div class="absolute top-0 left-0 right-0 ">
                    <div class="inline-block bg-indigo-200 p-2 rounded-full transform -translate-y-1/2">
                    <div class="px-2 py-3 h-16 w-16">
  <span id="count2" class="display-4 text-2xl oldstyle-nums text-red-900">0</span>
<span class="text-xl font-bold"></span>
  </div></div>
                  </div>
                  <div class="mt-10 uppercasec text-2xl text-indigo-700 font-extrabold">heading</div>
                  <div class="mt-2 text-base text-gray-600">lorem lrorem kroerm
                  </div>
                </div>
    </div>
    <div class=" flex  max-w-sm pt-16">
                <div class=" px-8 pb-8 shadow-2xl rounded-lg bg-gray-100 text-center relative">
                  <div class="absolute top-0 left-0 right-0 ">
                    <div class="inline-block bg-indigo-200 p-2 rounded-full transform -translate-y-1/2">
                    <div class="px-2 py-3 h-16 w-16">
  <span id="count3" class="display-4 text-2xl oldstyle-nums text-red-900">0</span>
<span class="text-xl font-bold"></span>
  </div></div>
                  </div>
                  <div class="mt-10 uppercasec text-2xl text-indigo-700 font-extrabold">heading</div>
                  <div class="mt-2 text-base text-gray-600">lorem lrorem kroerm
                  </div>
                </div>
    </div>
    <div class="flex  max-w-sm pt-16">
                <div class=" px-8 pb-8 shadow-2xl rounded-lg bg-gray-100 text-center relative">
                  <div class="absolute top-0 left-0 right-0 ">
                    <div class="inline-block bg-indigo-200 p-2 rounded-full transform -translate-y-1/2">
                    <div class="px-2 py-3 h-16 w-16">
  <span id="count4" class="display-4 text-2xl oldstyle-nums text-red-900">0</span>
<span class="text-xl font-bold"></span>
  </div></div>
                  </div>
                  <div class="mt-10 uppercasec text-2xl text-indigo-700 font-extrabold">heading</div>
                  <div class="mt-2 text-base text-gray-600">lorem lrorem kroerm
                  </div> -->
    </div>
</div>
<div class="relative md:flex">
<div class="absolute bg-green-400 bg-opacity-60 left-20   w-32 h-32 "></div>
    <div class=" mt-3">
        <h1 class="font-bold leading-tight text-center  p-5    h-40 w-40 bg-gray-800  bg-opacity-70 text-white relative" style="font-size: 28px">
            <!-- <div class="absolute bg-green-400 w-32 h-32 rounded-full"></div> -->
           <span class="absolute  ">Creative Services</span>
        </h1>
    </div>
    <div class="
                text-xl
                
                leading-normal
                transform
                transition
                duration-500
                px-5
                hover:scale-100
                text-white
                    ml-20
                    p-4
                pb-4" style="font-size: 18px">
        FYRA aspires to become your Online Partner. Not all solutions that
        we provide are in-house But we have tie-ups in the right places to
        give you great customized solutions. We are aggregators of all
        these services, whether in-house or through third-party. But the
        bottom-line responsibility lies with us. You will get a single
        point of contact for all the services, so you don’t have to worry
        about the co-ordination.
    </div>

</div>
</div>


<div class="
      grid
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-4
      grid-row-2
      lg: w-10/12
      gap-2
      ml-8
      mt-5
    ">
    <div class="
             bg-dark-blue grid-cols-2 col-span-2 sm:col-span-1 md:col-span-2 shadow-lg bg-opacity-30 rounded-lg
              border-1
           mb-1 transform transition-all ease-linear duration-300 hover:bg-opacity-60  hover:-translate-y-2" style="backdrop-filter:blur(80px);">
           <div class="text-2xl text-center">
            <p><span class="font-bold  text-yellow-300" style="border-bottom:5px solid red;">Branding</span></p>
        </div>
        <div>
        <img src="https://fyra.biz/static/img/branding.jpg" alt="product" class="w-52 h-32 object-contain  sm:h-48 md:h-64 rounded-full" />

        </div>
    </div>
    <div class="
           bg-blue-800 col-span-2 sm:col-span-1 md:col-span-2 shadow-lg bg-opacity-30 rounded-lg
              border-1
            mb-1 transform  transition-all ease-linear duration-300 hover:bg-opacity-60 hover:-translate-y-2" style="backdrop-filter:blur(80px);">
        <div class="text-xl text-center mb-2">
            <p><span class="font-bold text-yellow-300" style="">e-Commerce</span></p>
        </div>
        <img src="https://fyra.biz/static/img/ecommerce-small.jpeg" alt="product" class="w-52 h-32 object-contain h-32 sm:h-48 md:h-64" />
    </div>

    <div class="
        bg-blue-800 col-span-2 sm:col-span-1 md:col-span-2 shadow-lg bg-opacity-30 rounded-lg
              border-1
       mb-1 transform transition-all ease-linear duration-300 hover:bg-opacity-60  hover:-translate-y-2" style="backdrop-filter:blur(80px);">
        <div class="text-xl text-center mb-2">
            <p><span class="font-bold text-yellow-300" style="">Warehousing</span></p>
        </div>
        <img src="https://fyra.biz/static/img/warehosing-small.jpeg" alt="product" class="w-52 h-32  object-contain  sm:h-48 md:h-64" />
    </div>

    <div class="bg-blue-800 col-span-2 sm:col-span-1 md:col-span-2 shadow-lg bg-opacity-30 rounded-lg
          mb-1 transform transition-all ease-linear duration-300 hover:bg-opacity-60 hover:-translate-y-2" style="backdrop-filter:blur(80px);">
        <div class="text-xl text-center mb-2 relative">
            <p class=""><span class="font-bold text-yellow-300 " style="">Shipping <div class=""></div> </span></p>
        </div>
        <img src="https://fyra.biz/static/img/shipping-small.jpeg"  alt="People" class="w-52 h-20 object-contain  sm:h-48 md:h-64" />
    </div>
</div>

<div class="container mx-auto pt-16 shadow-xl lg: w-10/12 lg:ml-24
      ">
    <div class="pb-1 shadow-lg bg-blue-800 bg-opacity-30 rounded-lg m-4 bottom-top relative" style="backdrop-filter:blur(2px);">
        <a href="#" class="flex-1 pt-10">
            <h1 class="font-bold leading-tight sm:leading-normal text-yellow-300" style="font-size: 28px">
                What Our Customers Say!
            </h1>
        </a>
    </div>
    <br>

    <section id="carousel">
        <figure class="visible">
            <div class="flex flex-wrap justify-around shadow-lg bg-blue-800 bg-opacity-30 rounded-lg m-4 bottom-top relative" style="backdrop-filter:blur(2px);">
                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:pb-0 pb-12 mt-10">
                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                        <div class="bg-blue-800 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                            <h1 class="text-xl text-yellow-300 pb-1">Deepali Shewale</h1>
                            <p class="text-base text-indigo-100">Deeps Healthy</p>
                        </div>
                        <div class="pl-6 pr-6 pt-10 relative h-64 bg-white">
                            <div class="
                    h-16
                    w-16
                    rounded-full
                    bg-cover
                    border-4 border-white
                    absolute
                    top-0
                    right-0
                    -mt-8
                    mr-6
                  ">
                                <img src="https://fyra.biz/static/img/clients/deeps_healthy.png" alt="Deepali Shewale" role="img" class="
                      h-full
                      w-full
                      object-cover
                      rounded-full
                      overflow-hidden
                    " />
                            </div>

                            <p class="text-base text-gray-800  leading-8">
                                We believe in clean and nutritious diet - so deliver our customers healty grains or fruits.
                                Passerby Platform has helped us in tremendous way. The Platform manages all our digital presence!
                            </p>
                            <div class="flex justify-end mt-2">
                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg" class="">
                                    <path d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z" fill="#667EEA" fill-rule="evenodd" fill-opacity=".15" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12 mt-10">
                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                        <div class="bg-blue-800 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                            <h1 class="text-xl text-light-yellow pb-1">Fine Foods</h1>
                            <p class="text-base text-indigo-200">Fine Foods</p>
                        </div>
                        <div class="pl-6 pr-6 pt-10 relative h-64 bg-white">
                            <div class="
                    h-16
                    w-16
                    rounded-full
                    bg-cover
                    border-4 border-white
                    absolute
                    top-0
                    right-0
                    -mt-8
                    mr-6
                  ">
                                <img src="https://fyra.biz/static/img/clients/fine_foods.jpg" alt="Display Avatar of Ashley Wilson" role="img" class="
                      h-full
                      w-full
                      object-cover
                      rounded-full
                      overflow-hidden
                    " />
                            </div>

                            <p class="text-base text-gray-800 leading-8">
                                At Fine Food, we believe in making luxury common in making available products
                                of such quality to everyone in order to enjoy food as it was meant to be.
                                Passerby Platform helped us achieve our goals.
                            </p>
                            <div class="flex justify-end mt-2">
                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z" fill="#667EEA" fill-rule="evenodd" fill-opacity=".15" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                        <div class="bg-blue-800 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                            <h1 class="text-xl text-light-yellow pb-1">Bhajiwala</h1>
                            <p class="text-base text-indigo-200">Bhajiwala </p>
                        </div>
                        <div class="pl-6 pr-6 pt-10 relative h-64 bg-white">
                            <div class="
                    h-16
                    w-16
                    rounded-full
                    bg-cover
                    border-4 border-white
                    absolute
                    top-0
                    right-0
                    -mt-8
                    mr-6
                  ">
                                <img src="https://fyra.biz/static/img/clients/generic_avatar.jpeg" alt="Display Avatar of Richard Clark" role="img" class="
                      h-full
                      w-full
                      object-cover
                      rounded-full
                      overflow-hidden
                    " />
                            </div>

                            <p class="text-base text-gray-600 leading-8">
                                Serving Fresh Vegetables is our passion! Passerby Platform has helped us with Business Application
                                and User Application to serve our customers in extremely simple way.
                            </p>
                            <div class="flex justify-end mt-2">
                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z" fill="#667EEA" fill-rule="evenodd" fill-opacity=".15" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </figure>

        <figure class="hidden">
            <div class="flex flex-wrap justify-around">

            </div>
        </figure>

        <figure class="hidden">
            <div class="flex flex-wrap justify-around">
                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                        <div class="bg-blue-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                            <h1 class="text-xl text-light-yellow pb-1">Fleisch </h1>
                            <p class="text-base text-indigo-200">Fleisch - Online Meat Delivery </p>
                        </div>
                        <div class="pl-6 pr-6 pt-10 relative h-64 bg-white">
                            <div class="
                    h-16
                    w-16
                    rounded-full
                    bg-cover
                    border-4 border-white
                    absolute
                    top-0
                    right-0
                    -mt-8
                    mr-6
                  ">
                                <img src="https://fyra.biz/static/img/clients/generic_avatar.jpeg" alt="Display Avatar of Ashley Wilson" role="img" class="
                      h-full
                      w-full
                      object-cover
                      rounded-full
                      overflow-hidden
                    " />
                            </div>

                            <p class="text-base text-gray-600 leading-8">
                                It was pleasure to use Digital Marketing, Online Platform from Passerby folks. It's the platform which can help any
                                business to show digital presence in most easy fashion.
                            </p>
                            <div class="flex justify-end mt-2">
                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z" fill="#667EEA" fill-rule="evenodd" fill-opacity=".15" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:pb-0 pb-12">
                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                        <div class="bg-blue-800 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                            <h1 class="text-xl text-yellow-300 pb-1">Musketeers</h1>
                            <p class="text-base text-white">The 3 Musketeers Pub Pune</p>
                        </div>
                        <div class="pl-6 pr-6 pt-10 relative h-64 bg-white">
                            <div class="
                    h-16
                    w-16
                    rounded-full
                    bg-cover
                    border-4 border-white
                    absolute
                    top-0
                    right-0
                    -mt-8
                    mr-6
                  ">
                                <img src="/static/img/clients/generic_avatar.jpeg" alt="Display Avatar of Alex Parkinson" role="img" class="
                      h-full
                      w-full
                      object-cover
                      rounded-full
                      overflow-hidden
                    " />
                            </div>

                            <p class="text-base text-gray-600 leading-8">
                                We use Passerby Platform to manage our queue, manage tables, take orders from foodies!
                                It has helped us to smoothen our processes.
                            </p>
                            <div class="flex justify-end mt-2">
                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z" fill="#667EEA" fill-rule="evenodd" fill-opacity=".15" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <!--
                <div class="xl:w-1/3 lg:w-5/12 w-11/12 sm:w-3/5 md:w-5/12 xl:mb-0 mb-12">
                    <div class="shadow-lg mx-3 xl:mx-3 sm:mx-0 lg:mx-0 rounded">
                        <div class="bg-indigo-700 pt-6 pb-6 pl-6 rounded-tl rounded-tr">
                            <h1 class="text-xl text-white pb-1">Richard Clark</h1>
                            <p class="text-base text-indigo-200">Apple Inc</p>
                        </div>
                        <div class="pl-6 pr-6 pt-10 relative h-64">
                            <div class="
                    h-16
                    w-16
                    rounded-full
                    bg-cover
                    border-4 border-white
                    absolute
                    top-0
                    right-0
                    -mt-8
                    mr-6
                  ">
                                <img src="https://cdn.tuk.dev/assets/photo-1564061170517-d3907caa96ea.jfif" alt="Display Avatar of Richard Clark" role="img" class="
                      h-full
                      w-full
                      object-cover
                      rounded-full
                      overflow-hidden
                    " />
                            </div>

                            <p class="text-base text-gray-600 leading-8">
                                It really saves me time and effort. Chamer is exactly what our
                                business has been lacking. Chamer was worth a fortune to my
                                company.
                            </p>
                            <div class="flex justify-end mt-2">
                                <svg width="44" height="37" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.432 0c-2.339 0-4.329.821-5.97 2.463C.82 4.105 0 6.093 0 8.429c0 2.335.82 4.324 2.462 5.966 1.641 1.642 3.631 2.463 5.97 2.463 2.113 0 3.386.84 3.82 2.518.434 1.678.217 3.54-.65 5.583-.868 2.043-2.32 3.904-4.358 5.582C5.206 32.22 2.792 33.06 0 33.06V37c5.018 0 9.196-1.925 12.535-5.774 3.34-3.85 5.518-8.083 6.537-12.699 1.018-4.616.726-8.857-.878-12.725C16.591 1.934 13.337 0 8.432 0zm24.335 0c-2.34 0-4.33.821-5.97 2.463-1.642 1.642-2.462 3.63-2.462 5.966 0 2.335.82 4.324 2.462 5.966 1.64 1.642 3.63 2.463 5.97 2.463 2.113 0 3.396.84 3.848 2.518.453 1.678.236 3.54-.65 5.583-.887 2.043-2.34 3.904-4.358 5.582-2.019 1.679-4.443 2.518-7.272 2.518V37c5.018 0 9.196-1.925 12.535-5.774 3.339-3.85 5.518-8.083 6.536-12.699 1.02-4.616.727-8.857-.877-12.725C40.926 1.934 37.672 0 32.767 0z" fill="#667EEA" fill-rule="evenodd" fill-opacity=".15" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                -->
            </div>
        </figure>

    </section>
    <div class="
        cursor-pointer
        flex
        justify-center
        pt-4
        pb-8
        sm:pt-8
        md:pt-8
        lg:pt-8
        xl:pt-12
      ">
        <button aria-label="Move To previous Testimonials" role="button" @click="movePrev" class="focus:outline-none focus:ring-2 focus:ring-gray-400 rounded">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-left" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#CBD5E0" fill="none" stroke-linecap="round" stroke-linejoin="round" @click="movePrev()">
                <path stroke="none" d="M0 0h24v24H0z" />
                <polyline points="15 6 9 12 15 18" />
            </svg>
        </button>
        <button aria-label="Move to Next Testimonials" role="button" @click="moveForward" class="focus:outline-none focus:ring-2 focus:ring-gray-400 rounded">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-right" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#CBD5E0" fill="none" stroke-linecap="round" stroke-linejoin="round" @click="moveForward()">
                <path stroke="none" d="M0 0h24v24H0z" />
                <polyline points="9 6 15 12 9 18" />
            </svg>
        </button>
    </div>
</div>

<!-- Change the colour #f8fafc to match the previous section colour -->
<!-- <svg class="wave-top" viewBox="0 0 1439 147" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g transform="translate(-1.000000, -14.000000)" fill-rule="nonzero">
            <g class="wave" fill="#f8fafc">
                <path d="M1440,84 C1383.555,64.3 1342.555,51.3 1317,45 C1259.5,30.824 1206.707,25.526 1169,22 C1129.711,18.326 1044.426,18.475 980,22 C954.25,23.409 922.25,26.742 884,32 C845.122,37.787 818.455,42.121 804,45 C776.833,50.41 728.136,61.77 713,65 C660.023,76.309 621.544,87.729 584,94 C517.525,105.104 484.525,106.438 429,108 C379.49,106.484 342.823,104.484 319,102 C278.571,97.783 231.737,88.736 205,84 C154.629,75.076 86.296,57.743 0,32 L0,0 L1440,0 L1440,84 Z"></path>
            </g>
            <g transform="translate(1.000000, 15.000000)" fill="#FFFFFF">
                <g transform="translate(719.500000, 68.500000) rotate(-180.000000) translate(-719.500000, -68.500000) ">
                    <path d="M0,0 C90.7283404,0.927527913 147.912752,27.187927 291.910178,59.9119003 C387.908462,81.7278826 543.605069,89.334785 759,82.7326078 C469.336065,156.254352 216.336065,153.6679 0,74.9732496" opacity="0.100000001"></path>
                    <path d="M100,104.708498 C277.413333,72.2345949 426.147877,52.5246657 546.203633,45.5787101 C666.259389,38.6327546 810.524845,41.7979068 979,55.0741668 C931.069965,56.122511 810.303266,74.8455141 616.699903,111.243176 C423.096539,147.640838 250.863238,145.462612 100,104.708498 Z" opacity="0.100000001"></path>
                    <path d="M1046,51.6521276 C1130.83045,29.328812 1279.08318,17.607883 1439,40.1656806 L1439,120 C1271.17211,77.9435312 1140.17211,55.1609071 1046,51.6521276 Z" opacity="0.200000003"></path>
                </g>
            </g>
        </g>
    </g>
</svg> -->

<div class="grid grid-cols-1 divide-y divide-gray-100">
    <div></div>
    <div></div>
</div>
</div>
<!--Footer-->
<hr />
</template>

<script>
export default {
  name: 'Home',
  components: {
    // Carousel,
    // Pagination,
  // Navigation,
  },

  data () {
    return {

    }
  },
  methods: {
    scrollToTop () {
      window.scrollTo(0, 0)
    },

    getFigures () {
      return document.getElementById('carousel').getElementsByTagName('figure')
    },
    moveForward () {
      var pointer = 0
      var figures = this.getFigures()
      for (var i = 0; i < figures.length; i++) {
        if (figures[i].className === 'visible') {
          figures[i].className = 'hidden'
          pointer = i
          this.$data.current = pointer + 1
        }
      }
      if (++pointer === figures.length) {
        pointer = 0
      }
      figures[pointer].className = 'visible'
    },
    movePrev () {
      var figures = this.getFigures()
      for (var i = 0; i < figures.length; i++) {
        if (figures[i].className === 'visible') {
          figures[i].className = 'hidden'
        }
      }
      if (this.$data.current === 0) {
        this.$data.current = figures.length - 1
        figures[this.$data.current].className = 'visible'
      } else {
        this.$data.current = this.$data.current - 1
        figures[this.$data.current].className = 'visible'
      }
    }
  },

  mounted () {
    function left () {
      var lefts = document.querySelectorAll('.from-left')

      for (var i = 0; i < lefts.length; i++) {
        var windowHeight = window.innerHeight
        var elementTop = lefts[i].getBoundingClientRect().top
        var elementVisible = 150

        if (elementTop < windowHeight - elementVisible) {
          lefts[i].classList.add('active')
        } else {
          lefts[i].classList.remove('active')
        }
      }
    }
    function right () {
      var rights = document.querySelectorAll('.from-right')

      for (var i = 0; i < rights.length; i++) {
        var windowHeight = window.innerHeight
        var elementTop = rights[i].getBoundingClientRect().top
        var elementVisible = 150

        if (elementTop < windowHeight - elementVisible) {
          rights[i].classList.add('active')
        } else {
          rights[i].classList.remove('active')
        }
      }
    }
    function top () {
      var tops = document.querySelectorAll('.top-bottom')

      for (var i = 0; i < tops.length; i++) {
        var windowHeight = window.innerHeight
        var elementTop = tops[i].getBoundingClientRect().top
        var elementVisible = 150

        if (elementTop < windowHeight - elementVisible) {
          tops[i].classList.add('active')
        } else {
          tops[i].classList.remove('active')
        }
      }
      const counterAnim = (qSelector, start = 0, end, duration = 2000) => {
        const target = document.querySelector(qSelector)
        let startTimestamp = null
        const step = (timestamp) => {
          if (!startTimestamp) startTimestamp = timestamp
          const progress = Math.min((timestamp - startTimestamp) / duration, 1)
          target.innerText = Math.floor(progress * (end - start) + start)
          if (progress < 1) {
            window.requestAnimationFrame(step)
          }
        }
        window.requestAnimationFrame(step)
      }
      document.addEventListener('scroll', () => {
        counterAnim('#count1', 10, 300, 2000)
        counterAnim('#count2', 5000, 250, 2500)
        counterAnim('#count3', -1000, -150, 2000)
        counterAnim('#count4', 500, -100, 2500)
      })
    }
    window.addEventListener('scroll', left)
    window.addEventListener('scroll', right)
    window.addEventListener('scroll', top)
  }
}
</script>

<style  scoped>
@import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Source+Code+Pro&display=swap');

.rotate{
transform: rotate(30deg);
transform-origin: bottom left;
}
.rotate1{
    transform: rotate(45deg);
    transform-origin: bottom right;
}

.carousel__item {
    min-height: 400px;
    width: 100%;
    background-color: var(--carousel-color-primary);
    color: var(--carousel-color-white);
    font-size: 16px;
    border-radius: 8px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.carousel__slide {
    padding: 10px;
}

.carousel__prev,
.carousel__next {
    box-sizing: content-box;
    border: 5px solid white;
}

.uvp-list ul {
    display: inline-block;
    padding-left: 1.5rem;
    max-width: 320px;
}

.uvp-list ul {
    list-style: none;
}

.uvp-list ul>li {
    clear: left;
    padding: .2rem 0;
}

.uvp-list ul>li:before {
    content: "";
    height: 1.5rem;
    width: 1.5rem;
    display: block;
    float: left;
    margin-left: -1.5rem;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 100%;
}

.uvp-list ul>li:before {
   /*  background: url("/static/img/checkmark-round-orange.svg"); */
    background: url("/static/img/checkmark-round-blue.png");
    background-size: cover;
    background-position: center;
    padding: .15rem;
}
/* border */
.border-bottom{
  position: absolute;
   border-bottom:8px solid red;
   left:50%;
   right:0%;
}
/* button-animation */
.button_hb-type3:before{
	width: 110%;
	height: 0;
	opacity: 0;

	position: absolute;
	left: 50%;
	top: 50%;

	transform: translate3d(-50%, -50%, 0);
	will-change: opacity, height;

	transition-property: opacity, height;
	transition-duration: .25s, .25s;
  transition-delay: .15s, 0s;
  transition-timing-function: cubic-bezier(0, 0, 0.11, 1.24);
}

.button_hb-type3:hover:before, .button_hb-type3:focus:before{
	opacity: 1;
  height: 110%;
  transition-duration: .25s, .4s;
  transition-delay: 0s;
}
/* animation */
.from-left{

}
.from-left.active{
animation: from-left;
animation-direction: normal;
animation-duration: 2000ms;
animation-fill-mode: backwards;

}
@keyframes from-left {
    0%{
        transform: translateX(-200px);
        opacity: 0.3;
    }
    100%{
        transform: translateX(0px);
        opacity: 1;
    }
}
.bottom-top{
    animation: from-top;
animation-direction: normal;
animation-duration: 2000ms;
animation-fill-mode: backwards;
}
@keyframes from-top {
    0%{
        transform: translateY(-200px);
        opacity: 0.3;
    }
    100%{
        transform: translateY(0px);
        opacity: 1;
    }
}
.top-bottom{

}
.top-bottom.active{
    animation: from-top;
animation-direction: normal;
animation-duration: 2000ms;
animation-fill-mode: backwards;
}
@keyframes from-top {
    0%{
        transform: translateY(200px);
        opacity: 0.3;
    }
    100%{
        transform: translateY(0px);
        opacity: 1;
    }
}
.from-right{

}
.from-right.active{
    animation: from-right;
animation-direction: normal;
animation-duration: 2000ms;
animation-fill-mode: backwards;

}
@keyframes from-right {
    0%{
        transform: translateX(200px);
        opacity: 0.3;
    }
    100%{
        transform: translateX(0px);
        opacity: 1;
    }
}
.square{
font-family: 'Dancing Script', cursive;
  border-color: rgb(204, 77, 77);
  animation-name: example;
  animation-duration: 4s;
  /* /* animation-iteration-count: infinite;  */
}

@keyframes example {
  0%   {border-color: rgb(233, 41, 41);
  transform: Rotate(90deg);
  }
  100%
    {
transform: Rotate(0deg);
}
}


/* rolling words */
.sentence{
    margin: 0;
    text-align: left;

}
.sentence span{

    font-weight: normal;
}
.words{
    display: inline;
    text-indent: 10px;
}
.words-1 span{
    position: absolute;
    opacity: 0;
    overflow: hidden;
    color: #f1e31c;
    -webkit-animation: rotateWord 18s linear infinite 0s;
    -moz-animation: rotateWord 18s linear infinite 0s;
    -o-animation: rotateWord 18s linear infinite 0s;
    -ms-animation: rotateWord 18s linear infinite 0s;
    animation: rotateWord 18s linear infinite 0s;
}
.words-1 span:nth-child(2) {
    -webkit-animation-delay: 3s;
    -moz-animation-delay: 3s;
    -o-animation-delay: 3s;
    -ms-animation-delay: 3s;
    animation-delay: 3s;
    color: #c0e619;
}
.words-1 span:nth-child(3) {
    -webkit-animation-delay: 6s;
    -moz-animation-delay: 6s;
    -o-animation-delay: 6s;
    -ms-animation-delay: 6s;
    animation-delay: 6s;
    color: #d1d415;
}
.words-1 span:nth-child(4) {
    -webkit-animation-delay: 9s;
    -moz-animation-delay: 9s;
    -o-animation-delay: 9s;
    -ms-animation-delay: 9s;
    animation-delay: 9s;
    color: #f57676;
}
.words-1 span:nth-child(5) {
    -webkit-animation-delay: 12s;
    -moz-animation-delay: 12s;
    -o-animation-delay: 12s;
    -ms-animation-delay: 12s;
    animation-delay: 12s;
    color: #e98686;
}
.words-1 span:nth-child(6) {
    -webkit-animation-delay: 15s;
    -moz-animation-delay: 15s;
    -o-animation-delay: 15s;
    -ms-animation-delay: 15s;
    animation-delay: 15s;
   
}
@-webkit-keyframes rotateWord {
    0% { opacity: 0; }
    2% { opacity: 0; -webkit-transform: translateY(-30px); }
    5% { opacity: 1; -webkit-transform: translateY(0px);}
    17% { opacity: 1; -webkit-transform: translateY(0px); }
    20% { opacity: 0; -webkit-transform: translateY(30px); }
    80% { opacity: 0; }
    100% { opacity: 0; }
}
@-moz-keyframes rotateWord {
    0% { opacity: 0; }
    2% { opacity: 0; -moz-transform: translateY(-30px); }
    5% { opacity: 1; -moz-transform: translateY(0px);}
    17% { opacity: 1; -moz-transform: translateY(0px); }
    20% { opacity: 0; -moz-transform: translateY(30px); }
    80% { opacity: 0; }
    100% { opacity: 0; }
}
@-o-keyframes rotateWord {
    0% { opacity: 0; }
    2% { opacity: 0; -o-transform: translateY(-30px); }
    5% { opacity: 1; -o-transform: translateY(0px);}
    17% { opacity: 1; -o-transform: translateY(0px); }
    20% { opacity: 0; -o-transform: translateY(30px); }
    80% { opacity: 0; }
    100% { opacity: 0; }
}
@-ms-keyframes rotateWord {
    0% { opacity: 0; }
    2% { opacity: 0; -ms-transform: translateY(-30px); }
    5% { opacity: 1; -ms-transform: translateY(0px);}
    17% { opacity: 1; -ms-transform: translateY(0px); }
    20% { opacity: 0; -ms-transform: translateY(30px); }
    80% { opacity: 0; }
    100% { opacity: 0; }
}
@keyframes rotateWord {
    0% { opacity: 0; }
    2% { opacity: 0; transform: translateY(-30px); }
    5% { opacity: 1; transform: translateY(0px);}
    17% { opacity: 1; transform: translateY(0px); }
    20% { opacity: 0; transform: translateY(30px); }
    80% { opacity: 0; }
    100% { opacity: 0; }
}
.wave {
    position: absolute;
    bottom: -35px;
    left: 0;
    width: 100%;
    overflow: hidden;
    line-height: 0;
}

.wave svg {
    position: relative;
    display: block;
    width: calc(100% + 1.3px);
    height: 143px;
    transform: rotateY(180deg);
}

.wave .shape-fill {
    fill: #5a32a5;
}
.wave{
    animation-name: ani;
    animation-duration: 3000ms;
    animation-direction: normal;
    animation-fill-mode: initial;
}

h1 {
  font-family: "Montserrat Medium";
  max-width: 40ch;
  text-align: center;
  transform: scale(0.94);
  animation: scale 3s forwards cubic-bezier(0.5, 1, 0.89, 1);
}
@keyframes scale {
  100% {
    transform: scale(1);
  }
}

.head span {
  display: inline-block;
  opacity: 0;
  filter: blur(4px);
  padding: 4px;
}

.head span:nth-child(1) {
  animation: fade-in 0.8s 0.1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(2) {
  animation: fade-in 0.8s 0.2s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(3) {
  animation: fade-in 0.8s 0.3s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(4) {
  animation: fade-in 0.8s 0.4s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

 .head span:nth-child(5) {
  animation: fade-in 0.8s 0.5s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(6) {
  animation: fade-in 0.8s 0.6s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(7) {
  animation: fade-in 0.8s 0.7s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

span:nth-child(8) {
  animation: fade-in 0.8s 0.8s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(9) {
  animation: fade-in 0.8s 0.9s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(10) {
  animation: fade-in 0.8s 1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(11) {
  animation: fade-in 0.8s 1.1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(12) {
  animation: fade-in 0.8s 1.2s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(13) {
  animation: fade-in 0.8s 1.3s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(14) {
  animation: fade-in 0.8s 1.4s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(15) {
  animation: fade-in 0.8s 1.5s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

 .head span:nth-child(16) {
  animation: fade-in 0.8s 1.6s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

/* .head span:nth-child(17) {
  animation: fade-in 0.8s 1.7s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(18) {
  animation: fade-in 0.8s 1.8s forwards cubic-bezier(0.11, 0, 0.5, 0);
} */

@keyframes fade-in {
  100% {
    opacity: 1;
    filter: blur(0);
  }
}
.layer{
    background: transparent;
    height: 100%;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    transition: 0.5s;
    overflow: hidden;
    border-radius: 15px;
}

.layer:hover{
    background: rgba(226,0,0,0.7);
    
}

.layer h3{
    width: 100%;
    font-weight: 500;
    color: #fff;
    font-size: 26px;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    position: absolute;
    opacity: 0;
    transition: 0.5s;
}

.layer:hover h3{
    bottom: 49%;
    opacity: 1;
}
.border{
border-top-right-radius: 70px;
    border-bottom-left-radius: 30px;}
 .title{
     border-bottom: 20px;
     border-color: solid red;
 }
</style>
