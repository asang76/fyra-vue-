<template>
<!-- space creator -->
<br>
<br>
<br>

<div class="
      grid 
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
    ">
    <div class="col-span-2 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center md:text-xl lg:text-2xl ">
                Restaurant Passerby Platform!
            </h1>

            <!--div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div-->
            <div class="
            text-left 
            px-5
            text-sm md:text-xl
        
          ">
                The Passerby Platform supports Restaurant Dine In Experience. The platform help with: 
                <div class="mt-2 uvp-list text-sm md:text-xl">
                    <ul>
                        <li> Register Foodie in the Queue - Queue Management </li>
                        <li> Assign Table to the foodie </li>
                        <li> Foodie can place an order using Applications </li>
                        <li> The foodies can interact with waiter or manager througout the food session </li>
                    </ul>
                </div>

            </div>

            <div class="
            text-center
            leading-normal
            transform
            transition
            duration-500
            hover:scale-110
            mt-10
          " style="font-size: 16px">
                <a href="https://dashboard.passerby.in/register/">
                    <button class="
              
              hover:underline
              bg-indigo-600
              text-white
              font-bold
              rounded-full
              shadow-lg
              focus:outline-none
              focus:shadow-outline
              transform
              transition
              hover:scale-105
              duration-300
              ease-in-out
              w-25
              text-center
              p-2
              lg:mx-0
              md:my-6
              md:py-4
              md:px-8

            ">
                        Register
                    </button>
                </a> &nbsp; &nbsp;

                <a :href="$router.resolve({ name: 'Enquiry' }).href">
                    <button class="
             

              hover:underline
              bg-indigo-600
              text-white
              font-bold
              rounded-full
              shadow-lg
              focus:outline-none
              focus:shadow-outline
              transform
              transition
              hover:scale-105
              duration-300
              ease-in-out
             text-center
              w-25
            lg:mx-0
             p-2
             md:my-6
             md:py-4
             md:px-8
            ">
                        Send Enquiry
                    </button>
                </a>
            </div>
            
        </div>
    </div>

    <div class="bg-white p-2">
        <img src="https://fyra.biz/static/img/passerby_restaurant.jpg" class="mt-20" />

    </div>
</div>

<div class="
      h-screen
      grid 
      sm:grid-cols-1
      md:grid-cols-3
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
      sm:grid-cols-1
    ">
    
    
    <div class="h-96 relative p-2 sm:mt-1 md:mt-24">

              <div class="absolute w-48 overlap-down ">
                    <img src="https://fyra.biz/static/img/restaurant/left_drawer.jpg" class="" alt="">
                </div>
                <div class="absolute w-48 ml-12 overlap-up">
                    <img src="https://fyra.biz/static/img/restaurant/login_screen.jpg" class="" alt="">
                </div> 
    </div>

    <div class="col-span-2 bg-white mt-10 md:mt-24">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center" style="font-size: 28px">
                Manage Restaurant Using Passerby Business!
            </h1>

            <!--div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div-->
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                You can manage your Restaurant Along with your Foodies for various insights!
                <div class="uvp-list">
                    <ul>
                        <li> Manage Your Table Infrastructue</li>
                        <li> Manage your Queue Manager - they kind owners for Business Application </li>
                        <li> Manage your Waiters </li>
                        <li> Manage your Menu </li>
                        <li> Enable your Home Delivery!</li>
                        <li> Manage Offers</li>
                        <li> Configure Your WiFi Printers! </li>
                    </ul>
                </div>

            </div>

        </div>
    </div>

</div>

<div class="
      grid 
      sm:grid-cols-1
      md:grid-cols-3
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
    ">

    <div class="col-span-2 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center" style="font-size: 28px">
                Manage Restaurant Menu
            </h1>

            <!--div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div-->
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                You can manage your Menu and Images using single Dashboard.
                <div class="uvp-list">
                    <ul>
                        <li> Change Menu Prices Anytime you want</li>
                        <li> We support Food Category or Menu Item Based Taxes (CGST & SCST) </li>
                        <li> You can enable or Disable any Menu Item anytime in a single click </li>
                    </ul>
                </div>

            </div>

        </div>

    </div>

    <div class="bg-white p-2">
        <img src="https://fyra.biz/static/img/restaurant/laptop_mobile.jpg" class="mt-0" />
    </div>

</div>

<div class="
      grid 
      sm:grid-cols-1
      md:grid-cols-3
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
    ">

    <div class="bg-white p-2">
        <img src="https://fyra.biz/static/img/restaurant/manage_queue_together.jpeg" class="mt-1" />

    </div>

    <div class="col-span-2 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center" style="font-size: 28px">
                Manage Restaurant Queue
            </h1>

            <!--div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div-->
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                You can manage Foodie Queue!
                <div class="uvp-list">
                    <ul>
                        <li> Add Foodies along with PAX Size in Queue</li>
                        <li> You can take the Order before foodies can grab the table </li>
                        <li> Assign Tables </li>
                        <li> All interaction can be done digitally</li>
                        <li> You will understand the Foodies Favourite Food much before he grabs the table </li>
                        <li> You will know much more about your foodie as soon as he is in the queue </li>
                    </ul>
                </div>

            </div>

        </div>
    </div>

</div>

<div class="
      grid 
      sm:grid-cols-1
      md:grid-cols-3
      lg:grid-cols-3
      lg: w-10/12
      border-1 
      rounded-md
      shadow-xl
      lg:ml-24
      md:ml-40
      ml-8
      mt-3
    ">
    <div class="col-span-2 bg-white">
        <div class="md:p-1 bg-white flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center" style="font-size: 28px">
                Manage Restaurant Orders
            </h1>

            <!--div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div-->
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
          " style="font-size: 16px">
                You can manage all foodie orders using Passerby Business.
                <div class="uvp-list">
                    <ul>
                        <li> Help Foodies to decide on Foodie Menu</li>
                        <li> Instead of Pen and Paper - take order using Application </li>
                        <li> Orders are sent to Kitchen</li>
                        <li> Once Food is ready in kitchen - items can be delivered as and when required</li>
                        <li> Once Food Session is Over, Queue Manager can end the Session </li>
                        <li> The cheque/bill can be presented & reviewed and delivered to the Foodie instantly </li>
                    </ul>
                </div>

            </div>

        </div>
    </div>

    <div class="bg-white p-2">
        <img src="https://fyra.biz/static/img/restaurant/manage_orders.jpeg" class="mt-1" />

    </div>

</div>
</template>

<script>
export default {
    name: 'Restaurant',
}
</script> 

<style scoped>
.uvp-list ul {
    display: inline-block;
    padding-left: 1.5rem;
}

.uvp-list ul {
    list-style: none;
}

.uvp-list ul>li {
    clear: left;
    padding: .2rem 0;
}

.uvp-list ul>li:before {
    content: "";
    height: 1.5rem;
    width: 1.5rem;
    display: block;
    float: left;
    margin-left: -1.5rem;
    margin-right: 2px;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 100%;
}

.uvp-list ul>li:before {
    background: url("https://fyra.biz/static/img/checkmark-round-blue.png");
    background-size: cover;
    background-position: center;
    padding: .15rem;
}



.overlap-down {
    animation-name: up-down;
    animation-fill-mode: both;
    animation-direction: normal;
    animation-duration: 2000ms;
}

@keyframes up-down {
    0% {
        opacity: 0.4;
        bottom: 0px;
    }

    100% {
        opacity: 1;
        bottom: -100px;
    }
}

.overlap-down {
    webkit-animation-name: up-down;
    webkit-animation-fill-mode: both;
    webkit-animation-direction: normal;
    webkit-animation-duration: 2000ms;
}

@-webkit-keyframes up-down {
    0% {
        opacity: 0.4;
        bottom: 0px;
    }

    100% {
        opacity: 1;
        bottom: -100px;
    }
}

.overlap-up {
    animation-name: down-up;
    animation-direction: normal;
    animation-fill-mode: both;
    animation-duration: 2000ms;
}

@keyframes down-up {
    0% {
        opacity: 0.4;
        top: 0px;
    }

    100% {
        opacity: 1;
        top: -50px;
    }
}

.overlap-up {
    webkit-animation-name: down-up;
    webkit-animation-direction: normal;
    webkit-animation-fill-mode: both;
    webkit-animation-duration: 2000ms;
}

@-webkit-keyframes down-up {
    0% {
        opacity: 0.4;
        top: 0px;
    }

    100% {
        opacity: 1;
        top: -50px;
    }
}

</style>
