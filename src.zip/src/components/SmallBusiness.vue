<template>
<!-- space creator -->

<br>
<br>


<div class=" bg-contain bg-center bg-gradient-to-b from-purple-800 to-purple-600">
  <div class=" rounded-full text-white absolute font-extrabold  text-right opacity-30" style=" width:80px; height:40px;  font-size:100px; top:px; right:1px  backdrop-filter:blur(2px)">Shop Platform!
     </div>
<br>
<br>
<br>
<div>
    <div class="w-96 top-20 h-4/5 absolute right-1 "> <svg id="visual" viewBox="0 0 960 540" width="" height="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"><g transform="translate(394.6700127415268 205.73521185929957)"><path d="M142.9 -165.4C206.5 -150.5 293.9 -137.2 338.3 -89.1C382.6 -40.9 383.9 42.1 354.8 110.2C325.8 178.4 266.3 231.6 202.1 270.7C137.9 309.8 69 334.9 2.3 331.8C-64.5 328.7 -128.9 297.4 -163.2 248.6C-197.4 199.7 -201.4 133.2 -203.1 77.8C-204.8 22.5 -204.2 -21.8 -193.5 -65.5C-182.9 -109.1 -162.3 -152 -128.4 -176.5C-94.4 -201 -47.2 -207 -3.8 -201.8C39.7 -196.6 79.4 -180.2 142.9 -165.4" fill="#aba08c"></path></g></svg></div>
    <div class="grid grid-cols-2">
          <div class="relative w-full left-20 top-20 h-96">
    <!-- <div class="bg-green-600 w-96 h-96 rotate right-10  rounded-full -z-10 absolute opacity-25"></div>
    <div class="bg-yellow-600 w-72 h-72 rotate right-10 rounded-full -z-10 absolute opacity-25"></div> -->
        <div class="md:p-2 align-middle">
            <!--  <h1 class="text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-green-300 h-auto"> -->
            <h1 class=" sm:text-3xl md:text-4xl font-bold head text-2xl text-yellow-400 m-2">
  <span>Small</span>
  <span>Shop </span>
  <span>Platform</span>
  <span class="text-xl font-bold text-white ">The Passerby Platform Provide e-commerce support to Small Businesses. The Platform provide </span>
  <!-- <span>to </span>
  <span>what </span>
  <span>you </span>
  <span>can </span>
  <span>accomplish, </span>
  <span>except </span>
  <span>the </span>
  <span>limits </span>
  <span>you </span>
  <span>place </span>
  <span>on</span>
  <span>your</span>
  <span>own</span>
  <span>thinking.</span> -->
</h1>

        </div>
          <div class="
            text-center
            px-16
            leading-normal
            transform
            transition
            duration-500
            hover:scale-110
          " style="font-size: 16px">
                 <a href="https://dashboard.passerby.in/register/">
                     <button class="
              mx-auto
              lg:mx-0
              hover:underline
              bg-indigo-600
              text-white
              font-bold
              rounded-full
              my-6
              py-4
              px-8
              shadow-lg
              focus:outline-none
              focus:shadow-outline
              transform
              transition
              hover:scale-105
              duration-300
              ease-in-out
              w-25
              text-center
            ">
                         Register
                     </button>
                 </a> &nbsp; &nbsp;
                 <a >

                     <button class="
              mx-auto
              lg:mx-0
              hover:underline
              bg-indigo-600
              text-white
              font-bold
              rounded-full
              my-6
              py-4
              px-8
              shadow-lg
              focus:outline-none
              focus:shadow-outline
              transform
              transition
              hover:scale-105
              duration-300
              ease-in-out
              w-25
              text-center
            ">
                         Send Enquiry
                     </button>
                 </a>
             </div>
    </div>
    </div>
</div>
    <div class="wave ">
    <div class="custom-shape-divider-bottom-1643726750">
    <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
        <path d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z" class="shape-fill"></path>
    </svg>
</div>
 </div>
<div class="
      grid
      grid-cols-1
      sm:grid-cols-1
      md:grid-cols-1
      lg:grid-cols-3
w-full
      border-1
      rounded-md
      shadow-xl
      mt-56
       bg-dark-blue bg-opacity-60 rounded-lg relative bottom-top
    " style="backdrop-filter:blur(2px);
    ">
    <div class="col-span-2 ">
        <div class="md:p-1  flex flex-col flex-1">
            <h1 class="mt-5 mb-4 font-bold leading-tight text-center  heading text-yellow-400" style="font-size: 40px">
                
            </h1>

            <!--div class="text-blue-500 font-semibold text-2xs mb-2 leading-none" style="color: #4f47e5">
                Selling online is not difficult but its different
            </div-->
            <div class="
            text-left text-xl
            leading-normal
            transform
            transition
            duration-500
            px-5
            hover:scale-100
            text-white from-left
          " style="font-size: 20px">
                <!-- The Passerby Platform Provide e-commerce support to Small Businesses. The Platform provide -->
                <!-- <div class="uvp-list">
                    <ul>
                        <li> Business Application - it can help manage the orders and invoice the customers </li>
                        <li> Micro Sites - where users can browse the products and place the order </li>
                        <li> Dashboard can help consume the analytics and manage the products. </li>
                        <li> The platform can also help with digital marketing requirements. </li>
                    </ul>
                </div> -->

            </div>
            <div class="uvp-list flex justify-center  flex-wrap text-black ">
                    <div class=""><div class="w-96 h-52 p-4  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500 shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <h1 class="text-lg font-bold p-2 ">Business Application - it can help manage the orders and invoice the customers</h1>  <img class="w-20 h-20 ml-16" src="" alt="">
                         </div></div>
                    
                    <div class=""><div class="w-96 h-52 p-4  m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 border-gray-600 hover:border-gray-800  hover:bg-white transform hover:scale-110 transition-all duration-500   shadow-lg rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold p-2 w-full">Micro Sites - where users can browse the products and place the order </p> <img class="w-20 h-20 ml-16" src="https://ibb.co/JkzBBxb" alt=""> </div></div>
                   
                    <div class=""><div class="w-96 h-52 p-4 m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500  shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold p-4 w-full"> Dashboard can help consume the analytics and manage the products. </p> <img class="w-20 h-20 ml-16" src="https://ibb.co/3RHg9CB" alt=""> </div></div>
                    <div class=""><div class="w-96 h-52 p-4 m-6 border-b-8 border-purple-600 border-transparent hover:border-opacity-70 border bg-gray-200 hover:bg-white border-gray-600 hover:border-gray-800   transform hover:scale-110 transition-all duration-500  shadow-lg  rounded-lg  " style="backdrop-filter: blur(2px);">
                       <p class="text-lg font-bold p-4 w-full"> The platform can also help with digital marketing requirements </p> <img class="w-20 h-20 ml-16" src="https://ibb.co/3RHg9CB" alt=""> </div></div>
                   
                    <!-- <ul>
                        <li>Restaurants - Dine In and Home Delivery </li>
                        <li>Grocery Stores </li>
                        <li>Small and Medium Sized Enterprises (SME's) </li>
                        <li>Hyperlocal and E-Businesses </li>
                    </ul> -->
                </div>

           
        </div>
    </div>
    <div class="from-right p-2">
        <img src="https://fyra.biz/static/img/passerby_small.jpg" class="mt-20" />

    </div>
</div>
</div>
</template>

<script>
export default {
    name: 'SmallBusiness',
    mounted () {
    function left () {
      var lefts = document.querySelectorAll('.from-left')

      for (var i = 0; i < lefts.length; i++) {
        var windowHeight = window.innerHeight
        var elementTop = lefts[i].getBoundingClientRect().top
        var elementVisible = 150

        if (elementTop < windowHeight - elementVisible) {
          lefts[i].classList.add('active')
        } else {
          lefts[i].classList.remove('active')
        }
      }
    }
    function right () {
      var rights = document.querySelectorAll('.from-right')

      for (var i = 0; i < rights.length; i++) {
        var windowHeight = window.innerHeight
        var elementTop = rights[i].getBoundingClientRect().top
        var elementVisible = 150

        if (elementTop < windowHeight - elementVisible) {
          rights[i].classList.add('active')
        } else {
          rights[i].classList.remove('active')
        }
      }
    }
    function heading () {
      var headings = document.querySelectorAll('.heading')

      for (var i = 0; i < headings.length; i++) {
        var windowHeight = window.innerHeight
        var elementTop = headings[i].getBoundingClientRect().top
        var elementVisible = 150

        if (elementTop < windowHeight - elementVisible) {
          headings[i].classList.add('active')
        } else {
          headings[i].classList.remove('active')
        }
      }
    }
    window.addEventListener('scroll', left)
    window.addEventListener('scroll', right)
    window.addEventListener('scroll', heading)
  }
}
</script>

<style scoped>
.uvp-list ul {
    display: inline-block;
    padding-left: 1.5rem;
    max-width: 320px;
}

.uvp-list ul {
    list-style: none;
}

.uvp-list ul>li {
    clear: left;
    padding: .2rem 0;
}

.uvp-list ul>li:before {
    content: "";
    height: 1.5rem;
    width: 1.5rem;
    display: block;
    float: left;
    margin-left: -1.5rem;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 100%;
}

.uvp-list ul>li:before {
    background: url("/static/img/checkmark-round-blue.png");
    background-size: cover;
    background-position: center;
    padding: .15rem;
}
.wave {
    position: absolute;
    bottom: -35px;
    left: 0;
    width: 100%;
    overflow: hidden;
    line-height: 0;
}

.wave svg {
    position: relative;
    display: block;
    width: calc(100% + 1.3px);
    height: 143px;
    transform: rotateY(180deg);
}

.wave .shape-fill {
    fill: #5a32a5;
}
.wave{
    animation-name: ani;
    animation-duration: 3000ms;
    animation-direction: normal;
    animation-fill-mode: initial;
}
.head span {
  display: inline-block;
  opacity: 0;
  filter: blur(4px);
  padding: 4px;
}

.head span:nth-child(1) {
  animation: fade-in 0.8s 0.1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(2) {
  animation: fade-in 0.8s 0.2s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(3) {
  animation: fade-in 0.8s 0.3s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(4) {
  animation: fade-in 0.8s 0.4s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

 .head span:nth-child(5) {
  animation: fade-in 0.8s 0.5s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(6) {
  animation: fade-in 0.8s 0.6s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(7) {
  animation: fade-in 0.8s 0.7s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

span:nth-child(8) {
  animation: fade-in 0.8s 0.8s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(9) {
  animation: fade-in 0.8s 0.9s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(10) {
  animation: fade-in 0.8s 1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(11) {
  animation: fade-in 0.8s 1.1s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(12) {
  animation: fade-in 0.8s 1.2s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(13) {
  animation: fade-in 0.8s 1.3s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(14) {
  animation: fade-in 0.8s 1.4s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(15) {
  animation: fade-in 0.8s 1.5s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

 .head span:nth-child(16) {
  animation: fade-in 0.8s 1.6s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

/* .head span:nth-child(17) {
  animation: fade-in 0.8s 1.7s forwards cubic-bezier(0.11, 0, 0.5, 0);
}

.head span:nth-child(18) {
  animation: fade-in 0.8s 1.8s forwards cubic-bezier(0.11, 0, 0.5, 0);
} */

@keyframes fade-in {
  100% {
    opacity: 1;
    filter: blur(0);
  }
}
.border{
border-top-right-radius: 70px;
    border-bottom-left-radius: 30px;}
</style>
