<template>
 <div class="divide-y divide-gray-200 md:mt-20">
     <div class="pt-6 pb-8 space-y-2 md:space-y-5">
         <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl md:text-[4rem] md:leading-[3.5rem]">Latest</h1>
         <p class="text-lg text-gray-500">All News - About Passerby Platform</p>
     </div>
     <ul class="divide-y divide-gray-200">
         <li class="py-12">
             <article class="space-y-2 xl:grid xl:grid-cols-4 xl:space-y-0 xl:items-baseline">
                 <dl>
                     <dt class="sr-only">Published on</dt>
                     <dd class="text-base font-medium text-gray-500"><time datetime="2021-10-11T19:30:00.000Z">Oct 11, 2021</time></dd>
                 </dl>
                 <div class="space-y-5 xl:col-span-3">
                     <div class="space-y-6">
                         <h2 class="text-2xl font-bold tracking-tight"><a class="text-gray-900" href="/blogs/passerby-small-business">Introducing Small Business Passerby Applications</a></h2>
                         <div class="prose max-w-none text-gray-500">
                             <div class="prose max-w-none">
                                 <p>Passerby Platform can help small businesses like Dairy Farms, Cake Shops to manage customers, products using Online Platform. </p>
                             </div>
                         </div>
                     </div>
                     <div class="text-base font-medium">
                         <a class="mt-3 text-indigo-500 inline-flex items-center" href="/blogs/passerby-small-business" >Read More
                                <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 animate-ping  ml-2" viewBox="0 0 24 24">
                                    <path d="M5 12h14M12 5l7 7-7 7"></path>
                                </svg>
                            </a>
                         
                         </div>
                 </div>
             </article>
         </li>
     </ul>
 </div>
</template>

<script>

</script>
