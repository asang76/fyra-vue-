export default {

    active_link: state => state.active_link,
    contact_msg: state=> state.contact_msg,
    enquiry_msg: state=> state.enquiry_msg,
}